# テスト観点・条件 / カバレッジ項目

## 観点範囲

- 対象テスト要求: Eval Inputに記載された分類木組合せカバレッジ要求（TR IDは入力されていない）
- テストレベル: 未提示
- 対象外: なし（対象範囲を外す根拠は入力されていない）
- 仮定 / 未解決事項: factor値とFirefox + macOS + SAMLの成立不能制約、global 2-wise、指定subset 3-wiseは入力どおり採用する。期待される製品挙動、優先度、プロダクトリスクは未提示であり補わない。既存comb childのstable model keyとcurrent Entityが入力にないため、classification adapterからのchild dispatch、runtime生成、target mappingはブロック中。IDを推定して新規childへ置き換えない。

## テスト条件へ展開しないテスト要求

| テスト要求ID | 扱い | 理由 / 根拠 |
| --- | --- | --- |
| — | — | 独立したTR artifact / IDは入力されていない。Eval Inputの要求をTCN-001へ直接展開する。 |

## テスト観点・条件一覧

| 観点ID | テスト要求ID | テスト観点 / 条件 | カテゴリ | テスト技法 / 根拠 | カバレッジ基準 | 関連仕様根拠 / プロダクトリスク | 優先度 | 備考 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TCN-001 | Eval Input（TR ID未提示） | browser={Chrome, Firefox}、os={Windows, Linux, macOS}、auth={password, SAML}の分類木について、全因子pairwiseとsubset {browser, os, auth}の3-wiseで成立可能なtupleをカバー対象とする。Firefox + macOS + SAMLは除外する。 | 分類木・組合せ | classification adapter → 既存combinatorial child。child strategyはmixed-strength（global 2-wise、subset 3-wise）。adapter自身はexecution CIにしない。 | 3つのfactor pairそれぞれの成立可能値ペアを全件カバーし、subset {browser, os, auth}の成立可能3-factor tuple全件をカバーする。制約適用後のtupleを分母とし、strengthを下げない。 | 成立不能制約: SPEC-CTD-008。その他の製品期待結果・riskは未提示。 | 未提示 | child stable model key未提示につきruntime dispatchとtarget mappingはブロック中。test case / execution rowは生成しない。 |

## カバレッジ項目一覧

Pairwiseの候補母集団はbrowser×osの6組、browser×authの4組、os×authの6組で計16組。すべて少なくとも1つの許容completionを持つ。3-wise母集団は2×3×2=12通りから、SPEC-CTD-008で成立不能の1通りを除いた11組。以下は必要なCoverage Item候補であり、runtime target / 実行行へのmappingはchild identity解決後に行う。

| カバレッジ項目ID | 観点ID | カバレッジ項目 | 導出元の技法 / 基準 | 期待挙動の根拠 | 優先度 | 備考 |
| --- | --- | --- | --- | --- | --- | --- |
| TCN-001-CI01 | TCN-001 | browser=Chrome, os=Windows | Pairwise: browser×os | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI02 | TCN-001 | browser=Chrome, os=Linux | Pairwise: browser×os | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI03 | TCN-001 | browser=Chrome, os=macOS | Pairwise: browser×os | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI04 | TCN-001 | browser=Firefox, os=Windows | Pairwise: browser×os | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI05 | TCN-001 | browser=Firefox, os=Linux | Pairwise: browser×os | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI06 | TCN-001 | browser=Firefox, os=macOS | Pairwise: browser×os | 3-wise forbidden tuple以外のcompletionがあるためpairwiseでは成立可能。 | 未提示 | candidate tuple |
| TCN-001-CI07 | TCN-001 | browser=Chrome, auth=password | Pairwise: browser×auth | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI08 | TCN-001 | browser=Chrome, auth=SAML | Pairwise: browser×auth | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI09 | TCN-001 | browser=Firefox, auth=password | Pairwise: browser×auth | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI10 | TCN-001 | browser=Firefox, auth=SAML | Pairwise: browser×auth | macOS以外のcompletionがあるためpairwiseでは成立可能。 | 未提示 | candidate tuple |
| TCN-001-CI11 | TCN-001 | os=Windows, auth=password | Pairwise: os×auth | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI12 | TCN-001 | os=Windows, auth=SAML | Pairwise: os×auth | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI13 | TCN-001 | os=Linux, auth=password | Pairwise: os×auth | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI14 | TCN-001 | os=Linux, auth=SAML | Pairwise: os×auth | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI15 | TCN-001 | os=macOS, auth=password | Pairwise: os×auth | 組合せの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI16 | TCN-001 | os=macOS, auth=SAML | Pairwise: os×auth | Chrome completionがあるためpairwiseでは成立可能。 | 未提示 | candidate tuple |
| TCN-001-CI17 | TCN-001 | browser=Chrome, os=Windows, auth=password | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI18 | TCN-001 | browser=Chrome, os=Windows, auth=SAML | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI19 | TCN-001 | browser=Chrome, os=Linux, auth=password | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI20 | TCN-001 | browser=Chrome, os=Linux, auth=SAML | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI21 | TCN-001 | browser=Chrome, os=macOS, auth=password | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI22 | TCN-001 | browser=Chrome, os=macOS, auth=SAML | 3-wise: {browser, os, auth} | SPEC-CTD-008の制約に抵触しない許容tuple。 | 未提示 | candidate tuple |
| TCN-001-CI23 | TCN-001 | browser=Firefox, os=Windows, auth=password | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI24 | TCN-001 | browser=Firefox, os=Windows, auth=SAML | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI25 | TCN-001 | browser=Firefox, os=Linux, auth=password | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI26 | TCN-001 | browser=Firefox, os=Linux, auth=SAML | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |
| TCN-001-CI27 | TCN-001 | browser=Firefox, os=macOS, auth=password | 3-wise: {browser, os, auth} | 成立可能tupleの被覆項目。製品応答は未提示。 | 未提示 | candidate tuple |

## カバレッジ候補の扱い

| 候補 | 導出元 | 扱い | 理由 / 根拠 | カバー先 |
| --- | --- | --- | --- | --- |
| browser×osの全6組、browser×authの全4組、os×authの全6組 | 入力のfactor/value候補 | 採用 | 成立可能な全値ペアを明示。 | TCN-001-CI01–CI16 |
| {browser, os, auth}の全12候補中11組 | 入力のfactor/value候補と制約 | 採用 | SPEC-CTD-008の成立不能tupleを除いたfeasible tuple全件。 | TCN-001-CI17–CI27 |
| browser=Firefox + os=macOS + auth=SAML | SPEC-CTD-008 | 成立不能 | 入力がこの組合せを成立不能と明記している。coverage denominatorとCI一覧から除外。 | — |
| 既存comb childへのadapter dispatch | Eval Inputのchild再利用指定 | ブロック中 | stable model key / current Machine Entityが入力にない。既存childを確認できないため、child runtimeとtarget mappingを保留する。 | — |

## 任意: Pairwise / 組合せ

### 因子 / 値 / 制約

| 因子 | 値 | 制約 / 備考 |
| --- | --- | --- |
| browser | Chrome, Firefox | Eval Input |
| os | Windows, Linux, macOS | Eval Input |
| auth | password, SAML | Eval Input |
| 制約 | browser=Firefox AND os=macOS AND auth=SAML | 成立不能、SPEC-CTD-008 |

### 生成組合せ

| カバレッジ項目ID | 組合せ | 備考 |
| --- | --- | --- |
| — | 未生成 | CI01–CI27は必要tuple母集団の設計項目でありtest case / execution rowではない。既存comb child key未解決のためruntime rows / targetsは未生成。 |

### 2-wiseカバレッジ確認

- 生成方法 / ツール: mixed-strength combinatorial child（global strength 2、{browser, os, auth} subset strength 3）を指定。classification adapterからのdispatchはchild key未提示により保留。
- 制約: Firefox + macOS + SAMLを除外。
- 成立可能なすべての値ペアをカバレッジ項目でカバー済みか: 設計母集団として16/16組をCI01–CI16に列挙。runtime target / execution rowによる実カバー確認は未完了。
- 確認根拠: browser×os 6組、browser×auth 4組、os×auth 6組。禁止tupleは3因子制約であり、列挙したどのpairも許容completionを持つ。

## 統合候補

| 候補 | 統合理由 | カバー先 |
| --- | --- | --- |
| 3-wise全因子tupleは同じ3因子内のpairwise投影も満たす | pairwise条件は3-wise条件に論理的に含まれる。ただし両方の基準は入力指定どおり独立に追跡し、runtime childにも両strengthのtuple集合を要求する。 | TCN-001-CI17–CI27の射影がTCN-001-CI01–CI16をカバーする。 |

## Machine Runtime / Entity / Target mapping（機械証拠）

condition_structureのcurrent resultはTCN-001を生成したが`result_status=unresolved`であり、active model metadataは空。既存comb childのstable keyが確認できるまでclassification adapter / combinatorial child runtime、materialize、target-to-CI mappingは出力しない。Coverage Item候補一覧をruntime completeとは扱わない。
### Machine Runtime Input: test-condition-design::artifact:condition_structure:all

```json
{"input":{"inactive_materialize_history":[],"inactive_model_history":[],"inactive_model_keys":[],"inactive_tcn_history":[],"inactive_tcn_ids":[],"models":[],"previous_model_keys":[],"previous_tcn_ids":[],"requirement_dispositions":[],"technique_selections":[],"test_conditions":[{"authority_refs":["SPEC-CTD-008"],"category":"分類木・組合せ","condition":"browser={Chrome, Firefox}、os={Windows, Linux, macOS}、auth={password, SAML}の分類木で、全因子ペアワイズと{browser, os, auth}の3-wiseに必要な成立可能組合せをカバー対象とする。Firefox + macOS + SAMLはSPEC-CTD-008により成立不能。既存comb childへのclassification adapter展開はchildのstable model key未提示のため保留する。","coverage_criterion":"全factor pairwiseの成立可能値ペア、およびsubset {browser, os, auth} の成立可能3-wise tupleを各1回以上カバーする。制約適用後の全tupleを分母とし、strengthを下げない。comb childのstable model key確認後にruntime生成とtarget mappingを行う。","draft_key":"classification-mixed-strength","identity_action":"new","priority":"未提示","priority_override_reason":null,"reuse_id":null,"risk_refs":[],"technique_slugs":["comb"],"tr_refs":[]}],"test_requirements":[],"update_scope_model_keys":[],"update_scope_tcn_ids":[],"zero_scope_terminal":false},"metadata":{"authority_refs":["SPEC-CTD-008"],"envelope_version":"1","generator_contract_version":"condition-structure-v2","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:condition_structure:all","scope_key":"all","selection_key":null,"selection_source":null,"skill":"test-condition-design","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```
### Machine Runtime Result: test-condition-design::artifact:condition_structure:all

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:3e73266035662d05a64b4ea2755bb92a52be45c4e32c5955d6bdb5d321ea3c97","generator":"condition_structure","generator_contract_version":"condition-structure-v2","generator_implementation_fingerprint":"sha256:f57c22875c6852befe5825444681e3772c3951d5d1a5f720545c7d2b7f12f3c9","input_fingerprint":"sha256:fece9a90b93b1e1e4621fc4d76ac4b18ac57ac1f035fd5cf5bc8dac57181e24d","issues":[{"authority_refs":[],"blocking":true,"generation_fingerprint":"sha256:3e73266035662d05a64b4ea2755bb92a52be45c4e32c5955d6bdb5d321ea3c97","issue_type":"technique_set_mismatch","model_key":null,"runtime_unit_key":"artifact:condition_structure:all","skill":"test-condition-design","target_key":"violation:techniques:classification-mixed-strength"}],"model_fingerprint":null,"model_key":null,"payload":{"active_model_metadata":[],"derived_values":{"entities":[{"content":{"authority_refs":["SPEC-CTD-008"],"category":"分類木・組合せ","condition":"browser={Chrome, Firefox}、os={Windows, Linux, macOS}、auth={password, SAML}の分類木で、全因子ペアワイズと{browser, os, auth}の3-wiseに必要な成立可能組合せをカバー対象とする。Firefox + macOS + SAMLはSPEC-CTD-008により成立不能。既存comb childへのclassification adapter展開はchildのstable model key未提示のため保留する。","coverage_criterion":"全factor pairwiseの成立可能値ペア、およびsubset {browser, os, auth} の成立可能3-wise tupleを各1回以上カバーする。制約適用後の全tupleを分母とし、strengthを下げない。comb childのstable model key確認後にruntime生成とtarget mappingを行う。","priority":"未提示","priority_override_reason":null,"risk_refs":[],"scope_refs":[],"status":"active","tcn_id":"TCN-001","technique_slugs":["comb"],"tr_refs":[]},"content_fingerprint":"sha256:43e66647ea533403a3268d345f2a2b47c0b54936ae03c7fc038e121bac7cc058","entity_ref":"TCN-001","entity_type":"tcn","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:d698c681824c57386c96ee14c5d7f2617af5cc584f66dbae76365ef2f6c47c97","runtime_unit_key":"artifact:condition_structure:all#entity:sha256:6f007847f6b9f0a40c50385cf1f8db478a480c16652388b0dcadd2766a3ac0ce","skill":"test-condition-design"}],"schema_version":"entity-state-v2","skill":"test-condition-design","upstream_entity_dependencies":[]}]},"entities":[{"content":{"authority_refs":["SPEC-CTD-008"],"category":"分類木・組合せ","condition":"browser={Chrome, Firefox}、os={Windows, Linux, macOS}、auth={password, SAML}の分類木で、全因子ペアワイズと{browser, os, auth}の3-wiseに必要な成立可能組合せをカバー対象とする。Firefox + macOS + SAMLはSPEC-CTD-008により成立不能。既存comb childへのclassification adapter展開はchildのstable model key未提示のため保留する。","coverage_criterion":"全factor pairwiseの成立可能値ペア、およびsubset {browser, os, auth} の成立可能3-wise tupleを各1回以上カバーする。制約適用後の全tupleを分母とし、strengthを下げない。comb childのstable model key確認後にruntime生成とtarget mappingを行う。","priority":"未提示","priority_override_reason":null,"risk_refs":[],"scope_refs":[],"status":"active","tcn_id":"TCN-001","technique_slugs":["comb"],"tr_refs":[]},"content_fingerprint":"sha256:43e66647ea533403a3268d345f2a2b47c0b54936ae03c7fc038e121bac7cc058","entity_ref":"TCN-001","entity_type":"tcn","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:d698c681824c57386c96ee14c5d7f2617af5cc584f66dbae76365ef2f6c47c97","runtime_unit_key":"artifact:condition_structure:all#entity:sha256:6f007847f6b9f0a40c50385cf1f8db478a480c16652388b0dcadd2766a3ac0ce","skill":"test-condition-design"}],"schema_version":"entity-state-v2","skill":"test-condition-design","upstream_entity_dependencies":[]}],"expected_entity_identities":[{"entity_ref":"TCN-001","entity_type":"tcn","skill":"test-condition-design"}],"formal_design_summary":null,"inactive_materialize_history":[],"inactive_model_history":[],"inactive_tcn_history":[],"model_key_map":[],"model_key_state":[],"tcn_id_map":[{"draft_key":"classification-mixed-strength","identity_action":"new","tcn_id":"TCN-001"}],"tcn_id_state":[{"scope_refs":[],"status":"active","tcn_id":"TCN-001"}],"violations":[{"entity_ref":"classification-mixed-strength","issue_type":"technique_set_mismatch","target_key":"violation:techniques:classification-mixed-strength"}]},"result_status":"unresolved","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"ok","runtime_unit_key":"artifact:condition_structure:all","skill":"test-condition-design","static_data_versions":{},"support_status":"supported","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```
### Machine Entities: test-condition-design

```json
{"entities":[{"content":{"authority_refs":["SPEC-CTD-008"],"category":"分類木・組合せ","condition":"browser={Chrome, Firefox}、os={Windows, Linux, macOS}、auth={password, SAML}の分類木で、全因子ペアワイズと{browser, os, auth}の3-wiseに必要な成立可能組合せをカバー対象とする。Firefox + macOS + SAMLはSPEC-CTD-008により成立不能。既存comb childへのclassification adapter展開はchildのstable model key未提示のため保留する。","coverage_criterion":"全factor pairwiseの成立可能値ペア、およびsubset {browser, os, auth} の成立可能3-wise tupleを各1回以上カバーする。制約適用後の全tupleを分母とし、strengthを下げない。comb childのstable model key確認後にruntime生成とtarget mappingを行う。","priority":"未提示","priority_override_reason":null,"risk_refs":[],"scope_refs":[],"status":"active","tcn_id":"TCN-001","technique_slugs":["comb"],"tr_refs":[]},"content_fingerprint":"sha256:43e66647ea533403a3268d345f2a2b47c0b54936ae03c7fc038e121bac7cc058","entity_ref":"TCN-001","entity_type":"tcn","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:d698c681824c57386c96ee14c5d7f2617af5cc584f66dbae76365ef2f6c47c97","runtime_unit_key":"artifact:condition_structure:all#entity:sha256:6f007847f6b9f0a40c50385cf1f8db478a480c16652388b0dcadd2766a3ac0ce","skill":"test-condition-design"}],"schema_version":"entity-state-v2","skill":"test-condition-design","upstream_entity_dependencies":[]}],"schema_version":"entity-state-v2","skill":"test-condition-design"}
```

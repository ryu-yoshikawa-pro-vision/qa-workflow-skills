# E2E対象選定

## 判断範囲

- selection ref / revision: `E2ESEL-001` / revision 1（この成果物内の識別子。外部登録・readback未確認）
- current revision digest: `sha256:cc52decf66b9e96eda88704e5d78b50c5c2bde46a44542e35125da5165196607`
- current change reason: 初回記録。入力で候補source revisionを取得できず、候補母集団と対象境界も未確定であるため、採否判断を開始できない。必要sourceと候補集合を確定する担当ownerを割り当てた後に再開する。
- 自動化目的: UIを通る利用者／業務経路をE2E自動化する候補の価値を選定する。具体的な目的と対象境界は必要sourceの確認後に確定する。
- 候補母集団と完全性: 候補母集団・対象境界が未確定。候補を推測せず0件で記録し、`population_complete=false`。
- source refs / revisions / currentness (`REF@revision=current|stale|unknown`): `UI候補source（入力で参照先未提示）@unknown (not provided; unavailable in input)=unknown`。これは入力に実refがないことを示す記録用表記であり、実source refではない。
- retired candidate IDs / 理由: なし（初回revision）。
- 対象外: 個別のfeature/item/condition、TC直接指定、既存E2E実行は入力にないため作成・推測しない。TCやテストケースの作成、E2E実行も行わない。
- blocker / 再開条件:
  - 必要なUI候補sourceの実refとrevisionを取得できておらず、currentnessを確認できない。
  - 候補母集団・対象境界および具体的な自動化目的が未確定のため、候補を列挙できない。
  - 担当ownerが未割当。必要sourceと候補集合を確定する担当ownerを割り当てる。
  - owner割当後、目的・対象境界を確定し、必要なsource／Authorityの実ref、immutable revision、currentnessと候補集合の完全性を確認する。解消後は同じselection refのrevision 2として再評価し、このrevision 1の記録とdigestを履歴に保持する。
- 選定状態: **blocked**。入力の「完了した選定として提出」という要望だけではsource currentnessや母集団完全性を満たせないため、完了選定（ready）としては扱えない。

## 候補と判断

候補0件。候補母集団が未確定のため、候補行や採否を推測で作成しない。

| Candidate ID / key | feature / item / condition refs | E2E候補範囲 | decision | 技術非依存の価値・根拠 | source revision | 保留・重複・制約 |
| ------------------ | ------------------------------- | ----------- | -------- | ---------------------- | --------------- | ---------------- |

## 履歴

初回revisionのため、過去snapshotはない。

| revision | previous revision | candidate IDs / keys | decisions / rationale | source refs / revisions / currentness | retired candidate IDs / reason | change reason | revision digest |
| -------- | ----------------- | -------------------- | --------------------- | ------------------------------------- | ------------------------------ | ------------- | --------------- |

## 下流への受渡し

- 選定refを利用するconsumer: 未提示。owner割当とsource・scope確定後に決定する。
- 直接TC指定／E2E直接実行との区別: TC直接指定はなく、既存E2Eの実行依頼でもない。E2E候補の価値選定依頼だが、候補母集団未確定のためblocked。
- `e2e-test-inspection`へ渡す選定対象: なし。選定済み候補がないため、sourceと候補集合を確定して再評価した後に渡す。
- 未統合owner fixture / PR #22確認事項: 入力に情報がなく未確認。接続済み証拠とは扱わない。
- runtime / 保存確認: ローカル `selection_contract.py` はこのrecordを `blocked` として受理し、上記digestを返した。digestはrecord内容の整合性値であり、保存先への登録・readbackや保存先の真正性は確認していない。
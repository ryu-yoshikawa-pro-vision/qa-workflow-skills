# E2E対象選定

## 判断範囲

- selection ref / revision: `E2ESEL-001` / 1（初回選定）
- current revision digest: `sha256:127232dfda885528483b83734ab9d04607921c944246db4200fef951a20d0518`
- current change reason: 評価fixtureで閉じたTI-001/TI-002候補をcurrentな根拠に基づき評価する。
- 自動化目的: 主要なcheckout経路について、UIを通した反復的な利用者価値・業務完了の確認を行う価値を判断する。
- 候補母集団と完全性: TI-001（決済あり）とTI-002（決済なし）の2候補。評価入力が母集団を完全と明示している。
- source refs / revisions / currentness (`REF@revision=current|stale|unknown`): `E2E-01@e2e-r3=current`; `REQ-CHECKOUT@req-r4=current`; `TC-001@tc1-r5=current`; `TI-001@ti1-r1=current`; `TI-002@ti2-r1=current`。currentnessはこの評価fixtureで提供された根拠に基づく。
- retired candidate IDs / 理由: なし。
- 対象外: TC-001の直接選定・実行、既存E2Eの再実行、候補範囲外のcheckout経路。TC-001は重複評価のためのsourceとして参照する。
- blocker / 再開条件: 候補選定の判断 blocker なし。共有workflow runtimeやMachine Entityへの登録・保存readbackはこの評価入力に含まれないため、永続化されたcurrent recordとして利用する前にA ownerが登録先のreadbackを確認する。
- 選定状態: ready（runtime契約上の選定状態。currentnessは提供fixtureに基づく）

## 候補と判断

| Candidate ID / key | feature / item / condition refs | E2E候補範囲 | decision | 技術非依存の価値・根拠 | source revision | 保留・重複・制約 |
| ------------------ | ------------------------------- | ----------- | -------- | ---------------------- | --------------- | ---------------- |
| `E2E-CAND-001` / `TI-001:payment-checkout-completion` | `REQ-CHECKOUT`, `TI-001`, `TC-001` | 決済を伴うcheckout完了の利用者経路 | selected | 決済を伴うcheckout完了は主要業務経路であり、UIを通した反復確認には利用者視点でcheckoutから決済完了までの統合証拠を得る価値がある。現行E2Eはこの経路を対象にしていない。TC-001の既存system testとの重複はあるため、選定価値は利用者経路全体の確認に置く。 | `REQ-CHECKOUT@req-r4=current`; `TI-001@ti1-r1=current`; `TC-001@tc1-r5=current` | TC-001との範囲重複はあるが、現行E2Eにない決済あり経路の利用者視点の反復証拠を追加する。 |
| `E2E-CAND-002` / `TI-002:nonpayment-checkout` | `REQ-CHECKOUT`, `TI-002`, `E2E-01` | 決済なしcheckout経路 | not_selected | 決済なしcheckoutの同一経路を対象にするcurrentな既存E2E E2E-01があるため、新たなE2E候補を加える反復確認価値は重複する。既存E2E-01をこの経路の確認として扱う。 | `REQ-CHECKOUT@req-r4=current`; `TI-002@ti2-r1=current`; `E2E-01@e2e-r3=current` | 同じ経路をカバーする既存E2Eとの重複。別の未カバー業務リスクは入力に示されていない。 |

## 履歴

初回revisionのため過去snapshotはありません。

| revision | previous revision | candidate IDs / keys | decisions / rationale | source refs / revisions / currentness | retired candidate IDs / reason | change reason | revision digest |
| -------- | ----------------- | -------------------- | --------------------- | ------------------------------------- | ------------------------------ | ------------- | --------------- |

## 下流への受渡し

- 選定refを利用するconsumer: `e2e-test-inspection`。
- 直接TC指定／E2E直接実行との区別: 今回はcheckout E2E候補の価値選定依頼。TC-001はsourceとして参照しただけで、TCの直接指定・実行依頼ではない。既存E2Eの実行も依頼されていない。
- `e2e-test-inspection`へ渡す選定対象: `E2E-CAND-001`（TI-001、決済を伴うcheckout完了）。TC-001とのUI経路の重複範囲を確認する。
- 未統合owner fixture / PR #22確認事項: この記録のcurrentnessは評価fixtureの根拠に限る。実owner artifactの統合やPR #22接続の証拠は入力に含まれず、確認済みとは扱わない。
- 保存先readback: この評価ディレクトリの`e2e-selection.md`を保存先として作成し、内容を読み戻して確認した。これは共有workflow runtime／Machine Entityへの登録・保存を証明しない。
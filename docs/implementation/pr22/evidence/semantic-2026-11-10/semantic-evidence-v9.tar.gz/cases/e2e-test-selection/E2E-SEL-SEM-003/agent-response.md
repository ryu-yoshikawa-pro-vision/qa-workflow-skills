# E2E対象選定

## 判断範囲

- selection ref / revision: `E2ESEL-004` / `2`
- current revision digest: `sha256:33a09a35c79b6a89956d1b0f4c4d5d6fe53f4ba6c2943047349b5af16ffe957b`
- current change reason: TI-002のsource revision更新とTI-003の候補追加
- 自動化目的: 利用者の主要checkout経路を反復確認する技術非依存の価値選定
- 候補母集団と完全性: TI-001、TI-002、TI-003。入力で示された母集団は完全（`population_complete=true`）。
- source refs / revisions / currentness (`REF@revision=current|stale|unknown`):
  - `E2E-01@e2e-r3=current`（fixture入力値）
  - `REQ-CHECKOUT@req-r4=current`（fixture入力値）
  - `REQ-ORDER-TRACKING@req-track-r1=current`（fixture入力値）
  - `TI-001@ti1-r1=current`（fixture入力値）
  - `TI-002@ti2-r2=current`（今回の入力値）
  - `TI-003@unknown=unknown`（TI-003自体のimmutable revision/currentnessは未提示）
  - currentnessの記録は評価fixtureの値に基づく。source ownerの正本を別途読み戻して確認したものではない。
- retired candidate IDs / 理由: なし
- 対象外: TCを直接選ぶ依頼、既存E2Eの実行、Product Risk／TR／TCN／CI／TCの新規作成、locator・fixture・実装可否・実装コストの評価。
- blocker / 再開条件:
  - `E2E-CAND-003`（`order-tracking`）: TI-003のimmutable revisionとcurrentnessがない。TI-003のrevision tokenとcurrentnessを確認し、同じselection IDのrevision 3で再評価する。
  - `E2E-CAND-002`（`checkout-shipping`）: 配送再試行の価値は認められるが、fixtureには`E2E-01@e2e-r3`の対象経路が記載されていない。既存E2Eの範囲を確認して重複を判断する。
- 選定状態: **blocked**（runtime status `blocked`; history complete; unresolved candidates: `E2E-CAND-002`, `E2E-CAND-003`; unresolved source: `TI-003`）

## 候補と判断

| Candidate ID / key | feature / item / condition refs | E2E候補範囲 | decision | 技術非依存の価値・根拠 | source revision | 保留・重複・制約 |
| ------------------ | ------------------------------- | ----------- | -------- | ---------------------- | --------------- | ---------------- |
| `E2E-CAND-001` / `checkout-primary` | `REQ-CHECKOUT`, `TI-001` | 主要checkout完了経路 | selected | 主要checkout完了経路をUIから反復確認する価値がある | `REQ-CHECKOUT@req-r4=current`; `TI-001@ti1-r1=current` | sourceと経路に変更がないためrevision 1の判断を維持。 |
| `E2E-CAND-002` / `checkout-shipping` | `E2E-01`, `REQ-CHECKOUT`, `TI-002` | 配送再試行経路 | deferred | TI-002 revision ti2-r2に配送再試行経路が追加され、主要checkoutとは異なる利用者経路をUIから反復確認する価値が見込まれる。一方、fixtureにはE2E-01@e2e-r3の対象経路が示されておらず、既存E2Eとの重複を判断できないため、E2E-01の対象範囲を確認してから採否を確定する。 | `E2E-01@e2e-r3=current`; `REQ-CHECKOUT@req-r4=current`; `TI-002@ti2-r2=current` | 既存E2Eとの重複範囲が未確認。E2E-01の対象経路を確認して再評価。 |
| `E2E-CAND-003` / `order-tracking` | `REQ-ORDER-TRACKING`, `TI-003` | 注文追跡経路 | blocked | 注文追跡は注文後の利用者経路だが、TI-003自体のimmutable revisionとcurrentnessが提示されていないため現行sourceに基づく判断を確定できない。TI-003のrevision/currentnessを確認して再評価する。 | `REQ-ORDER-TRACKING@req-track-r1=current`; `TI-003@unknown=unknown` | TI-003のrevision/currentnessを確認してから再評価。 |

## 履歴

履歴はrevision 1の完全snapshot。revision 1のfixture digestをruntimeで検証し、一致を確認した。

| revision | previous revision | candidate IDs / keys | decisions / rationale | source refs / revisions / currentness | retired candidate IDs / reason | change reason | revision digest |
| -------- | ----------------- | -------------------- | --------------------- | ------------------------------------- | ------------------------------ | ------------- | --------------- |
| 1 | 初回 | `E2E-CAND-001` / `checkout-primary`; `E2E-CAND-002` / `checkout-shipping` | `E2E-CAND-001`: selected — 主要checkout完了経路をUIから反復確認する価値がある。`E2E-CAND-002`: deferred — 現行source上は配送条件の反復確認価値が未評価。 | 全source: `E2E-01@e2e-r3=current`; `REQ-CHECKOUT@req-r4=current`; `TI-001@ti1-r1=current`; `TI-002@ti2-r1=current`。候補別: `001`=`REQ-CHECKOUT`, `TI-001`; `002`=`REQ-CHECKOUT`, `TI-002`。 | なし | 初回のE2E自動化価値判断 | `sha256:4d5f0ed37a58d7e6d001dace61ed748d9fd18f0e382efe3a8d0d2b9b7794d464` |

### Revision 1 snapshot

```json
{
  "revision": 1,
  "previous_revision": null,
  "candidate_ids": [
    {"candidate_id": "E2E-CAND-001", "candidate_key": "checkout-primary"},
    {"candidate_id": "E2E-CAND-002", "candidate_key": "checkout-shipping"}
  ],
  "change_reason": "初回のE2E自動化価値判断",
  "retired_candidates": [],
  "selection_snapshot": {
    "scope_refs": ["TI-001", "TI-002"],
    "automation_goal": "利用者の主要checkout経路を反復確認する技術非依存の価値選定",
    "population_complete": true,
    "source_refs": [
      {"ref": "E2E-01", "revision": "e2e-r3", "currentness": "current"},
      {"ref": "REQ-CHECKOUT", "revision": "req-r4", "currentness": "current"},
      {"ref": "TI-001", "revision": "ti1-r1", "currentness": "current"},
      {"ref": "TI-002", "revision": "ti2-r1", "currentness": "current"}
    ],
    "candidates": [
      {
        "candidate_id": "E2E-CAND-001",
        "candidate_key": "checkout-primary",
        "source_refs": ["REQ-CHECKOUT", "TI-001"],
        "decision": "selected",
        "rationale": "主要checkout完了経路をUIから反復確認する価値がある"
      },
      {
        "candidate_id": "E2E-CAND-002",
        "candidate_key": "checkout-shipping",
        "source_refs": ["REQ-CHECKOUT", "TI-002"],
        "decision": "deferred",
        "rationale": "現行source上は配送条件の反復確認価値が未評価"
      }
    ],
    "blockers": []
  },
  "revision_digest": "sha256:4d5f0ed37a58d7e6d001dace61ed748d9fd18f0e382efe3a8d0d2b9b7794d464"
}
```

runtimeのrevision 1 digestはfixtureの`current_revision_digest`と一致した。revision 2のdigestは上記current revision digest。digestはrecord整合性値であり、source ownerや保存先の真正性は証明しない。

## 下流への受渡し

- 選定refを利用するconsumer: `e2e-test-inspection`。現時点で選定済みの候補は`E2E-CAND-001`。`E2E-CAND-002`は重複確認後、`E2E-CAND-003`はTI-003のrevision/currentness確認後に受け渡す。
- 直接TC指定／E2E直接実行との区別: TCの直接指定はない。明示された業務経路候補の価値選定であり、TCは作成していない。既存E2Eの実行もしていない。
- `e2e-test-inspection`へ渡す選定対象: `E2E-CAND-001`。候補002・003は上記の未解決条件が解消した後に再評価する。
- 未統合owner fixture / PR #22確認事項: これは評価fixtureに基づく記録。実owner artifactの統合やPR #22接続証拠は確認していない。
- 保存確認: 成果物はこの孤立評価ディレクトリ内に作成。共有workflow runtime／Machine Entityへの保存・readbackは行っていない。
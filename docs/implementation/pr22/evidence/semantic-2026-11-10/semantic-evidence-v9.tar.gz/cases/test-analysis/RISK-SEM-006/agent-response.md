# テスト分析

## テスト分析範囲

- 対象機能 / 変更: 画像を圧縮して保存する処理。入力画像を再エンコードした後も、同じ縦横比と仕様上の許容サイズを満たす関係が示されている。
- 案件固有のテスト目的 / 重点: Metamorphic Testingを採用し、どの範囲を重点化するか判断する。
- テストレベル: システムテスト（別レベルの指定がないため既定を適用）。
- 環境制約: 実装、実行環境、操作入口、利用可能な画像形式は未提示。
- 対象外: 入力で示されていない画質、性能、形式別挙動の期待結果。
- ブロッカー: 「許容サイズ」の意味（画像寸法かファイル容量か等）、単位、上下限・包含条件が入力にない。サイズ条件だけ合否判定を保留し、根拠の確認を`question-analysis`へ渡す。縦横比関係の分析は継続する。
- 対象 / 実行範囲: テスト分析

## 変更 / 影響マップ

| 領域 | 変更種別 | 根拠 / 依存関係 | 想定影響 |
| ---- | -------- | --------------- | -------- |
| 画像圧縮後の再エンコード・保存 | 変更 | 提供入力の変更説明と「再エンコードしても同じ縦横比と許容サイズを満たす」という仕様情報 | 再エンコード後に比率または許容サイズ条件を外れ、出力が仕様不適合となる可能性。直接の回帰候補。 |

## プロダクトリスク一覧

| リスクID | 製品上のリスク / 失敗 | 関連する現在有効な仕様根拠 / 変更 / 依存 | 影響度 | 発生可能性 | レベル | 根拠 | 判断信頼度 / 備考 |
| -------- | --------------------- | ---------------------------------------- | -----: | ---------: | ------ | ---- | ----------------- |
| RISK-001 | 再エンコード後の画像が縦横比または許容サイズ条件を満たさず、保存結果が仕様に適合しない。 | 提供入力にある再エンコード前後の縦横比・許容サイズ関係、および画像圧縮保存処理の変更。 | 3 | 3 | 高 | 不適合出力は画像保存という主要機能の重大な誤動作になり得る。再エンコード処理の変更は意味のある発生要因。影響範囲や実装詳細の情報はない。 | 低。実装方式、差分、既往不具合、利用範囲が未提示。数値は定性的ヒューリスティック評価。 |

## テスト重点

| 優先度 | 重点領域 | 関連プロダクトリスク / 根拠 | 設計深度 / 備考 |
| ------ | -------- | --------------------------- | --------------- |
| 高 | 再エンコード前後の縦横比関係。test-condition-designが定義する全source × follow-up candidate pairを対象とする。 | RISK-001。提供入力で明示された関係。 | リスク高の深度で、選択した技法のカバレッジを満たす。1組だけの確認で代替せず、定義された全pairを扱う。具体的なsource・follow-up集合とpairは`test-condition-design`へ渡す。 |
| 高 | 許容サイズの関係。 | RISK-001。許容サイズを満たすという記載はあるが、判定基準が未確定。 | 基準確定後、同じ全source × follow-up candidate pairへ反映する。現時点ではサイズ条件の合否を作らず、`question-analysis`で仕様根拠を確定する。 |

## 選択したテスト技法

| テスト技法 | 適用領域 | 選択理由 | 関連プロダクトリスク / 現在有効な仕様根拠 | `test-condition-design`への着眼点 |
| ---------- | -------- | -------- | ----------------------------------------- | --------------------------------- |
| Metamorphic Testing | 元画像と再エンコード後に保存された画像の縦横比関係。サイズ条件は仕様明確化後に適用。 | 出力の具体的な画素列やバイト列が同一である必要はなく、入力と追試出力の間に保つべき関係が明示されているため。 | RISK-001。提供入力にある「再エンコードしても同じ縦横比と許容サイズを満たす」関係。 | 全source × follow-up candidate pairを対象にする。具体的なsource、follow-up、pair、実行生成は本分析では定義せず、後続で確定する。サイズの意味・単位・境界が確認されるまで、その関係の期待結果は保留する。 |

## テスト可能性 / テストレベル判断

| 要件 / 懸念 | 操作可能か | 観測可能か | 合否判定可能か | 選択テストレベル | 扱い / 備考 |
| ----------- | ---------- | ---------- | -------------- | ---------------- | ---------- |
| 再エンコード後も縦横比を保つ | 一部 | 可 | 可 | システムテスト | 対象フローは特定されているが、実際の操作入口は未提示。保存後画像の寸法から入力との比率一致を観測・判定する。 |
| 再エンコード後に許容サイズを満たす | 一部 | 一部 | 不可 | システムテスト | 「サイズ」の測定対象、単位、許容境界が不明。サイズ基準の仕様確認まで当該条件をブロック中とする。 |

## 残存リスク

| リスク / 要件 | 十分にカバーできない理由 | 推奨対応 |
| ------------- | ------------------------ | -------- |
| 許容サイズ条件 | 対象量（ピクセル寸法またはファイル容量等）、単位、上下限、境界の包含が入力で特定されない。 | `question-analysis`で現在有効な仕様根拠と判定条件を確認し、解決後に全source × follow-up candidate pairへ追加する。 |
| 実際の操作・出力観測 | 実装や操作入口、対応形式が未提示。 | 後続のテスト設計で対象システムの操作経路と保存出力の観測方法を確認する。 |

## Machine Runtime / Entity（機械証拠）

### Machine Runtime Input: test-analysis::artifact:risk_matrix:all

```json
{"input":{"risks":[{"impact":3,"likelihood":3,"risk_id":"RISK-001"}],"scheme":{"kind":"repository-default","scheme_key":"risk-scheme-v1"}},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"risk-matrix-v1","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:risk_matrix:all","scope_key":null,"selection_key":null,"selection_source":null,"skill":"test-analysis","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```

### Machine Runtime Result: test-analysis::artifact:risk_matrix:all

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:ab96b4bc49f6c2c139e295ba0a5bb8151b20f8d2423764fff56d3464d301aadf","generator":"risk_matrix","generator_contract_version":"risk-matrix-v1","generator_implementation_fingerprint":"sha256:55b2789ba1ff67be8de30577665a6f5d414d792c07fc3569a5ce62da61348e3c","input_fingerprint":"sha256:0915c9b0a04b63b2367cd9262d00d1b4cd73f3d861c239d9a43c4060fc5132df","issues":[],"model_fingerprint":null,"model_key":null,"payload":{"risks":[{"level":"高","mapped_priority":"高","risk_id":"RISK-001"}],"scheme_key":"risk-scheme-v1"},"result_status":"ready","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"ok","runtime_unit_key":"artifact:risk_matrix:all","skill":"test-analysis","static_data_versions":{},"support_status":"supported","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```

### Machine Runtime Input: test-analysis::artifact:technique_candidates:image-reencode

```json
{"input":{"selection_key":"image-reencode","signals":{"crud_model":false,"equivalence_classes":false,"explicit_boundaries":false,"explicit_flow":false,"grammar_model":false,"metamorphic_relation":true,"multi_variable_domain":false,"multiple_discrete_conditions":false,"multiple_factors":false,"operational_profile":false,"ordered_domain":false,"stateful":false}},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"technique-candidates-v1","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:technique_candidates:image-reencode","scope_key":null,"selection_key":null,"selection_source":null,"skill":"test-analysis","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```

### Machine Runtime Result: test-analysis::artifact:technique_candidates:image-reencode

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:313984c1046bf77b784d74bd733b99a24408452a67e996150c5b000d9b24a80b","generator":"technique_candidates","generator_contract_version":"technique-candidates-v1","generator_implementation_fingerprint":"sha256:48937114ecf991a11c5e6671bffe816ef5e1425654f3ff3a4e80a23dd197529d","input_fingerprint":"sha256:95a1359712734a5a89931f45a4a6b97a90508ceab8392951bc5e0bfbebc6d8d0","issues":[],"model_fingerprint":null,"model_key":null,"payload":{"candidates":["Metamorphic Testing"],"complete":true,"selection_key":"image-reencode","undetermined_signals":[]},"result_status":"ready","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"ok","runtime_unit_key":"artifact:technique_candidates:image-reencode","skill":"test-analysis","static_data_versions":{},"support_status":"supported","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```

### Machine Runtime Input: test-analysis::artifact:analysis_entities:all

```json
{"input":{"change_edges":[],"change_nodes":[],"current_runtime_units":[{"generation_fingerprint":"sha256:ab96b4bc49f6c2c139e295ba0a5bb8151b20f8d2423764fff56d3464d301aadf","runtime_unit_key":"artifact:risk_matrix:all","skill":"test-analysis"},{"generation_fingerprint":"sha256:313984c1046bf77b784d74bd733b99a24408452a67e996150c5b000d9b24a80b","runtime_unit_key":"artifact:technique_candidates:image-reencode","skill":"test-analysis"}],"environment_requirements":[],"product_risks":[{"assessment_reason":"再エンコードして保存する処理が変更対象であり、変換時に比率や出力サイズが変わる失敗は主要機能の重大な誤動作につながり得る。変更は意味のある複雑性要因だが、実装詳細や既往不具合は未提示のため発生可能性は定性的に評価した。","authority_refs":[],"confidence_note":"低。実装方式、変更差分、既往不具合、利用範囲の情報がない。","failure":"再エンコード後の画像が縦横比または許容サイズ条件を満たさず、保存結果が仕様に適合しない","impact":3,"likelihood":3,"risk_id":"RISK-001","source_refs":[]}],"risk_matrix_results":[{"level":"高","mapped_priority":"高","risk_id":"RISK-001"}],"technique_candidate_results":[{"candidates":["Metamorphic Testing"],"selection_key":"image-reencode","undetermined_signals":[]}],"technique_selections":[{"applicability_scope":"画像圧縮後に再エンコードして保存する変更。縦横比の関係を先行対象とし、サイズ基準は定義待ち。","authority_refs":[],"condition_design_focus":["test-condition-designで定義する全source × follow-up candidate pairに対して縦横比の関係を扱う","許容サイズ条件は意味・単位・境界が確定してから対象へ追加する"],"risk_refs":["RISK-001"],"selected_techniques":["metamorphic"],"selection_key":"image-reencode","selection_reason":"入力と再エンコード後出力の間に、縦横比を保つという明示された関係があり、個々の出力バイト列を固定せず関係を検証するMetamorphic Testingが適合する。","selection_source":"analysis","signals":{"crud_model":false,"equivalence_classes":false,"explicit_boundaries":false,"explicit_flow":false,"grammar_model":false,"metamorphic_relation":true,"multi_variable_domain":false,"multiple_discrete_conditions":false,"multiple_factors":false,"operational_profile":false,"ordered_domain":false,"stateful":false},"status":"active","undetermined_signal_closures":[]}],"test_analysis_context":{"authority_refs":[],"blockers":["許容サイズの意味、単位、境界が未特定のためサイズ条件の合否判定は保留"],"environment_constraints":["実装・実行環境・操作入口は入力に示されていない"],"exclusions":["入力に規定されていない画質、性能、形式別挙動の期待結果"],"objectives":["Metamorphic Testingの採用と重点を判断する"],"residual_risks":["許容サイズがピクセル寸法かファイル容量かを含め、サイズ条件の判定根拠が未確定","具体的なsource・follow-up集合とpairの定義はtest-condition-designで行う"],"risk_refs":["RISK-001"],"scope":"画像圧縮・再エンコード保存処理の変更に伴う縦横比および許容サイズ関係","test_focus_items":["全source × follow-up candidate pairで、再エンコード後も同じ縦横比を保つ関係を確認する","サイズ条件の根拠が確定した後、全candidate pairを同じ関係の対象に含める"],"test_levels":["システムテスト"],"testability_decisions":["再エンコード・保存の対象操作は特定されているが、実際の操作入口は未提示","保存画像の縦横寸法から比率関係を観測できる。サイズの観測値は基準の明確化が必要","縦横比一致は判定可能。許容サイズ条件は定義不足のため判定不可"]}},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"analysis-entities-v1","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:analysis_entities:all","scope_key":null,"selection_key":null,"selection_source":null,"skill":"test-analysis","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[{"generation_fingerprint":"sha256:ab96b4bc49f6c2c139e295ba0a5bb8151b20f8d2423764fff56d3464d301aadf","runtime_unit_key":"artifact:risk_matrix:all","skill":"test-analysis"},{"generation_fingerprint":"sha256:313984c1046bf77b784d74bd733b99a24408452a67e996150c5b000d9b24a80b","runtime_unit_key":"artifact:technique_candidates:image-reencode","skill":"test-analysis"}]}}
```

### Machine Runtime Result: test-analysis::artifact:analysis_entities:all

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:57f60a6871ef76da25bdbfced971b7d5dbd53c6462e3f2e349f079de9a545474","generator":"analysis_entities","generator_contract_version":"analysis-entities-v1","generator_implementation_fingerprint":"sha256:34702ac842a0e5f92c510d45cfad6eb9478741653e8d517ffd7de66e03118b73","input_fingerprint":"sha256:79d274ff2623185f5370c3156e9d152ebd71c1d58b961fa4429dee0762a10fe4","issues":[],"model_fingerprint":null,"model_key":null,"payload":{"expected_entity_identities":[{"entity_ref":"RISK-001","entity_type":"product_risk","skill":"test-analysis"},{"entity_ref":"image-reencode","entity_type":"technique_selection","skill":"test-analysis"},{"entity_ref":"analysis-context:all","entity_type":"test_analysis_context","skill":"test-analysis"}],"machine_entities":[{"content":{"assessment_reason":"再エンコードして保存する処理が変更対象であり、変換時に比率や出力サイズが変わる失敗は主要機能の重大な誤動作につながり得る。変更は意味のある複雑性要因だが、実装詳細や既往不具合は未提示のため発生可能性は定性的に評価した。","authority_refs":[],"confidence_note":"低。実装方式、変更差分、既往不具合、利用範囲の情報がない。","failure":"再エンコード後の画像が縦横比または許容サイズ条件を満たさず、保存結果が仕様に適合しない","impact":3,"level":"高","likelihood":3,"mapped_priority":"高","risk_id":"RISK-001","source_refs":[]},"content_fingerprint":"sha256:6991d5bb2b83423f2955e4b6a94c68726e73519bfc94524005986ff20b7252c4","entity_ref":"RISK-001","entity_type":"product_risk","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:ab96b4bc49f6c2c139e295ba0a5bb8151b20f8d2423764fff56d3464d301aadf","runtime_unit_key":"artifact:risk_matrix:all","skill":"test-analysis"},{"generation_fingerprint":"sha256:313984c1046bf77b784d74bd733b99a24408452a67e996150c5b000d9b24a80b","runtime_unit_key":"artifact:technique_candidates:image-reencode","skill":"test-analysis"}],"schema_version":"entity-state-v2","skill":"test-analysis","upstream_entity_dependencies":[]},{"content":{"applicability_scope":"画像圧縮後に再エンコードして保存する変更。縦横比の関係を先行対象とし、サイズ基準は定義待ち。","authority_refs":[],"candidates":["Metamorphic Testing"],"condition_design_focus":["test-condition-designで定義する全source × follow-up candidate pairに対して縦横比の関係を扱う","許容サイズ条件は意味・単位・境界が確定してから対象へ追加する"],"risk_refs":["RISK-001"],"selected_techniques":["metamorphic"],"selection_key":"image-reencode","selection_reason":"入力と再エンコード後出力の間に、縦横比を保つという明示された関係があり、個々の出力バイト列を固定せず関係を検証するMetamorphic Testingが適合する。","selection_source":"analysis","signals":{"crud_model":false,"equivalence_classes":false,"explicit_boundaries":false,"explicit_flow":false,"grammar_model":false,"metamorphic_relation":true,"multi_variable_domain":false,"multiple_discrete_conditions":false,"multiple_factors":false,"operational_profile":false,"ordered_domain":false,"stateful":false},"status":"active","undetermined_signals":[]},"content_fingerprint":"sha256:8d2cd61491c2e26baedfd5897c1a81cb768544eb00d1764d2df091ff49663989","entity_ref":"image-reencode","entity_type":"technique_selection","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:ab96b4bc49f6c2c139e295ba0a5bb8151b20f8d2423764fff56d3464d301aadf","runtime_unit_key":"artifact:risk_matrix:all","skill":"test-analysis"},{"generation_fingerprint":"sha256:313984c1046bf77b784d74bd733b99a24408452a67e996150c5b000d9b24a80b","runtime_unit_key":"artifact:technique_candidates:image-reencode","skill":"test-analysis"}],"schema_version":"entity-state-v2","skill":"test-analysis","upstream_entity_dependencies":[{"content_fingerprint":"sha256:6991d5bb2b83423f2955e4b6a94c68726e73519bfc94524005986ff20b7252c4","entity_ref":"RISK-001","entity_type":"product_risk","skill":"test-analysis"}]},{"content":{"authority_refs":[],"blockers":["許容サイズの意味、単位、境界が未特定のためサイズ条件の合否判定は保留"],"environment_constraints":["実装・実行環境・操作入口は入力に示されていない"],"exclusions":["入力に規定されていない画質、性能、形式別挙動の期待結果"],"objectives":["Metamorphic Testingの採用と重点を判断する"],"residual_risks":["許容サイズがピクセル寸法かファイル容量かを含め、サイズ条件の判定根拠が未確定","具体的なsource・follow-up集合とpairの定義はtest-condition-designで行う"],"risk_refs":["RISK-001"],"scope":"画像圧縮・再エンコード保存処理の変更に伴う縦横比および許容サイズ関係","test_focus_items":["全source × follow-up candidate pairで、再エンコード後も同じ縦横比を保つ関係を確認する","サイズ条件の根拠が確定した後、全candidate pairを同じ関係の対象に含める"],"test_levels":["システムテスト"],"testability_decisions":["再エンコード・保存の対象操作は特定されているが、実際の操作入口は未提示","保存画像の縦横寸法から比率関係を観測できる。サイズの観測値は基準の明確化が必要","縦横比一致は判定可能。許容サイズ条件は定義不足のため判定不可"]},"content_fingerprint":"sha256:fa99204e89c96eb92e50c243d078b4aeba01b6e5d1ea2aac415c0b212860cd19","entity_ref":"analysis-context:all","entity_type":"test_analysis_context","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:ab96b4bc49f6c2c139e295ba0a5bb8151b20f8d2423764fff56d3464d301aadf","runtime_unit_key":"artifact:risk_matrix:all","skill":"test-analysis"},{"generation_fingerprint":"sha256:313984c1046bf77b784d74bd733b99a24408452a67e996150c5b000d9b24a80b","runtime_unit_key":"artifact:technique_candidates:image-reencode","skill":"test-analysis"}],"schema_version":"entity-state-v2","skill":"test-analysis","upstream_entity_dependencies":[{"content_fingerprint":"sha256:6991d5bb2b83423f2955e4b6a94c68726e73519bfc94524005986ff20b7252c4","entity_ref":"RISK-001","entity_type":"test_analysis_context","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:ab96b4bc49f6c2c139e295ba0a5bb8151b20f8d2423764fff56d3464d301aadf","runtime_unit_key":"artifact:risk_matrix:all","skill":"test-analysis"},{"generation_fingerprint":"sha256:313984c1046bf77b784d74bd733b99a24408452a67e996150c5b000d9b24a80b","runtime_unit_key":"artifact:technique_candidates:image-reencode","skill":"test-analysis"}],"schema_version":"entity-state-v2","skill":"test-analysis","upstream_entity_dependencies":[]}]}],"schema_version":"entity-state-v2","skill":"test-analysis"}
```
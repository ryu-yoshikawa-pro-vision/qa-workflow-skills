# テスト観点・条件 / カバレッジ項目

## 観点範囲

- 対象テスト要求: Eval Inputに記載されたテストデータ要件 `R-ROLE`、`R-A-LOW`、`R-A-HIGH`、`R-B-VERSION` の適用対象と、対象ごとの同一次元intersection
- テストレベル: 未指定
- 対象外: なし
- 仮定 / 未解決事項: `A`、`B`は入力中のcurrent targetラベルとして扱う。入力はtarget-version参照がcurrent targetのsource model、`target_ref`、`target_content_fingerprint`、`generation_fingerprint`と一致すると明示しているが、runtimeが要求する実際のdigest値とcurrent model Machine Entityは与えられていない。片側だけのversion境界もSkill-local runtimeのbounded `version_range` schemaへ忠実に符号化できない。以下の適用対象と競合は入力に明記されたtarget scopeと不等式から導出し、runtimeのblocked結果を意味上の競合判定には使わない。

## テスト条件へ展開しないテスト要求

入力に独立したTR IDや製品動作のテスト要求はなく、以下はテストデータ要件の適用対象・整合性の分析である。

| テスト要求ID | 扱い | 理由 / 根拠 |
| ------------ | ----- | ----------- |

## 適用対象と競合

| 要件ID | 要件 / dimension | applicable target refs | 対象ごとの結果 |
| ------ | ---------------- | ---------------------- | -------------- |
| R-ROLE | `role ∈ {admin, guest}` | A, B | 両targetへ適用。role dimensionの単独要件にintersection conflictなし。 |
| R-A-LOW | `version >= 2.0` | A | R-A-HIGHと同じtarget・dimensionで評価。 |
| R-A-HIGH | `version <= 1.4` | A | R-A-LOWとのintersectionが空。Aで競合。 |
| R-B-VERSION | `version = 1.3` | B | Bだけに適用。Aのversion要件とは交差させず、B内では競合なし。 |

**影響target:** A — `R-A-LOW ∩ R-A-HIGH = ∅`。両条件を満たすversionはない。B — 競合なし。`R-B-VERSION`の許容値は1.3であり、Aの要件はBへ適用しない。

## テスト観点・条件一覧

入力に製品動作のテスト要求がないため、テスト条件は採番しない。

| 観点ID | テスト要求ID | テスト観点 / 条件 | カテゴリ | テスト技法 / 根拠 | カバレッジ基準 | 関連仕様根拠 / プロダクトリスク | 優先度 | 備考 |
| ------- | ------------ | ----------------- | -------- | ----------------- | -------------- | ------------------------------- | ------ | ---- |

## カバレッジ項目一覧

テスト条件がないため、coverage itemは採番しない。

| カバレッジ項目ID | 観点ID | カバレッジ項目 | 導出元の技法 / 基準 | 期待挙動の根拠 | 優先度 | 備考 |
| ---------------- | ------ | -------------- | ------------------- | -------------- | ------ | ---- |

## カバレッジ候補の扱い

| 候補 | 導出元 | 扱い | 理由 / 根拠 | カバー先 |
| ---- | ------ | ---- | ----------- | -------- |
| `R-ROLE` on A and B | model-wide target scope | 採用 | Eval Inputで両current targetに適用すると明記。 | 適用対象と競合 |
| `R-A-LOW` × `R-A-HIGH` | target A / version | 採用 | 同一target・同一次元。`version >= 2.0`と`version <= 1.4`の共通値がない。 | 適用対象と競合 |
| `R-B-VERSION` | target B / version | 採用 | Eval InputでBだけに適用。Aの制約と交差しない。 | 適用対象と競合 |
| Aのversion要件 × Bのversion要件 | target-specific scope | 対象外 | 異なるcurrent targetの要件であり、同時成立intersectionの母集団ではない。coverage-techniques.mdのTest Data Requirements規則。 | — |
| Machine runtimeでdigest target identityを照合 | Skill-local TDR runtime contract | ブロック中 | 提示された識別子はA/Bラベルであり、実target digest値とcurrent model Machine Entityがない。追加の実値を作らず、runtime evidenceはinvalid_inputとして保持する。 | — |

## Machine Runtime / Entity / Target mapping（機械証拠）

condition_structureは入力にテスト条件・モデルdraftがないため空のcurrent structureを返した。TDR runtimeはA/Bラベルとfingerprint未提示のtarget rowsをdigest形式のcurrent target identityへ解決できず、`invalid_input` / `blocked`を返した。したがって4件のtest-data requirement Machine Entityは生成されず、runtime evidenceを完成済みとして扱えない。競合結論は入力の明示的なtarget scopeとversion不等式から導出しており、製品判定ではない。

### Machine Runtime Input: test-condition-design::artifact:condition_structure:all

```json
{"input":{"inactive_materialize_history":[],"inactive_model_history":[],"inactive_model_keys":[],"inactive_tcn_history":[],"inactive_tcn_ids":[],"models":[],"previous_model_keys":[],"previous_tcn_ids":[],"requirement_dispositions":[],"technique_selections":[],"test_conditions":[],"test_requirements":[],"update_scope_model_keys":[],"update_scope_tcn_ids":[],"zero_scope_terminal":false},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"condition-structure-v2","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:condition_structure:all","scope_key":"all","selection_key":null,"selection_source":null,"skill":"test-condition-design","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```
### Machine Runtime Result: test-condition-design::artifact:condition_structure:all

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:42e5c402944c37254c2f24172ec0029c89fad84df01e6a159dbe89312e7e82a2","generator":"condition_structure","generator_contract_version":"condition-structure-v2","generator_implementation_fingerprint":"sha256:f57c22875c6852befe5825444681e3772c3951d5d1a5f720545c7d2b7f12f3c9","input_fingerprint":"sha256:c47b51668b10d847d81fbb621d1830f16e93ce3921f3d35a6a2cc1b2f58ad7b8","issues":[],"model_fingerprint":null,"model_key":null,"payload":{"active_model_metadata":[],"derived_values":{"entities":[]},"entities":[],"expected_entity_identities":[],"formal_design_summary":null,"inactive_materialize_history":[],"inactive_model_history":[],"inactive_tcn_history":[],"model_key_map":[],"model_key_state":[],"tcn_id_map":[],"tcn_id_state":[],"violations":[]},"result_status":"ready","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"ok","runtime_unit_key":"artifact:condition_structure:all","skill":"test-condition-design","static_data_versions":{},"support_status":"supported","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```
### Machine Runtime Input: test-condition-design::artifact:test_data_requirements:all

```json
{"input":{"current_source_targets":[{"generation_fingerprint":null,"source_model_key":"M-ORDERS","target_content_fingerprint":null,"target_ref":"A"},{"generation_fingerprint":null,"source_model_key":"M-ORDERS","target_content_fingerprint":null,"target_ref":"B"}],"requirements":[{"authority_refs":[],"dimension_key":"role","environment_key":null,"operator":"enum","requirement_key":"R-ROLE","source_model_key":"M-ORDERS","source_target_versions":[],"values":[{"type":"enum","value":"admin"},{"type":"enum","value":"guest"}]},{"authority_refs":[],"dimension_key":"version","environment_key":null,"maximum":null,"maximum_inclusive":true,"minimum":"2.0","minimum_inclusive":true,"operator":"version_range","requirement_key":"R-A-LOW","source_model_key":"M-ORDERS","source_target_versions":[{"generation_fingerprint":null,"target_content_fingerprint":null,"target_ref":"A"}]},{"authority_refs":[],"dimension_key":"version","environment_key":null,"maximum":"1.4","maximum_inclusive":true,"minimum":null,"minimum_inclusive":true,"operator":"version_range","requirement_key":"R-A-HIGH","source_model_key":"M-ORDERS","source_target_versions":[{"generation_fingerprint":null,"target_content_fingerprint":null,"target_ref":"A"}]},{"authority_refs":[],"dimension_key":"version","environment_key":null,"maximum":"1.3","maximum_inclusive":true,"minimum":"1.3","minimum_inclusive":true,"operator":"version_range","requirement_key":"R-B-VERSION","source_model_key":"M-ORDERS","source_target_versions":[{"generation_fingerprint":null,"target_content_fingerprint":null,"target_ref":"B"}]}]},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"test-data-requirements-v1","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:test_data_requirements:all","scope_key":"all","selection_key":null,"selection_source":null,"skill":"test-condition-design","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```
### Machine Runtime Result: test-condition-design::artifact:test_data_requirements:all

```json
{"deterministic_generated":false,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:b0a38c8fb0f9b321bdb3ed4fd2c9d48b25b695f1199df590dc6ad08c79303262","generator":"test_data_requirements","generator_contract_version":"test-data-requirements-v1","generator_implementation_fingerprint":"sha256:6c8779ee77b9126971ef5eb5a1f77b66dbf8a94f0bc6618179805330f7c15faa","input_fingerprint":"sha256:b2b298267c792d3ce17c99b4d0e62e25497e92876d52063b2fe86dd413809842","issues":[{"blocking":true,"generation_fingerprint":"sha256:b0a38c8fb0f9b321bdb3ed4fd2c9d48b25b695f1199df590dc6ad08c79303262","issue_type":"invalid_input","message":"current_source_targetsのdigestが不正です","model_key":null,"runtime_unit_key":"artifact:test_data_requirements:all","skill":"test-condition-design","target_key":null}],"model_fingerprint":null,"model_key":null,"payload":{},"result_status":"blocked","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"invalid_input","runtime_unit_key":"artifact:test_data_requirements:all","skill":"test-condition-design","static_data_versions":{},"support_status":"unknown","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```
### Machine Entities: test-condition-design

```json
{"entities":[],"schema_version":"entity-state-v2","skill":"test-condition-design"}
```

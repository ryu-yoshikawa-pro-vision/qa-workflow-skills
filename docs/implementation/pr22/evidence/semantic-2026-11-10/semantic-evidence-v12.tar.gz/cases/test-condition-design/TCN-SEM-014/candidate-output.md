# テスト観点・条件 / カバレッジ項目

## 観点範囲

- 対象テスト要求: current target closure と model completion の構造評価
- テストレベル: モデル / runtime coverage structure
- 対象外: 製品挙動のテスト条件。入力は既存targetのclosure評価に限定され、挙動要求・仕様根拠・リスクは提示されていない
- 仮定 / 未解決事項: fingerprintの値は提示された値を使用し、execution fingerprintは入力にある一致関係を使用。Cに対応するcurrent terminal dispositionは提示されていない

## テスト条件へ展開しないテスト要求

| テスト要求ID | 扱い | 理由 / 根拠 |
| --- | --- | --- |

behavioral TRは入力されていない。ここでは製品挙動のTCNを追加しない。

## Target closure / model completion

閉鎖基準: 各current targetがcurrent CI mappingまたは妥当なcurrent terminal dispositionへ到達すること。`重複`は参照先のcurrent versionへ解決し、循環せずterminalへ到達すること。

| Target | Stable target_ref | Current version | 到達状態 | 判定 |
| --- | --- | --- | --- | --- |
| A | `sha256:7f95b25231b722e357e2735a4b95b82ed84c9c8d61278e4b102c591aee5c6db2` | content `sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`; generation `sha256:cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc` | `重複` → B current version → CI-001 current mapping（execution fingerprint一致） | 閉鎖。自己参照・cycleなし |
| B | `sha256:c457862906171627acaf2afad37f3de8c7b4404112006514776ca28f29317444` | content `sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb`; generation `sha256:dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd` | CI-001 current mapping（execution fingerprint一致） | 閉鎖 |
| C | `sha256:1f2d2a3e6790340559a24194a6e40280ec7c74a3046cad81c0767547470a6af6` | content `sha256:eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee`; generation `sha256:ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff` | CIに未到達。current terminal dispositionも入力にない | 入力上は未閉鎖 |

- Current target母集団: A, B, C（3件）
- Closed target: A, B（2件）
- Model completion: incomplete。Cの閉鎖根拠がなく、全current targetを閉じた状態を確認できない
- Cに別のcurrent terminal dispositionが存在する場合は、そのrecordとversionを追加して再評価する

## テスト観点・条件一覧

| 観点ID | テスト要求ID | テスト観点 / 条件 | カテゴリ | テスト技法 / 根拠 | カバレッジ基準 | 関連仕様根拠 / プロダクトリスク | 優先度 | 備考 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

製品挙動のテスト条件は生成していない。入力された構造評価結果は上記Target closure表に記録した。

## カバレッジ項目一覧

| カバレッジ項目ID | 観点ID | カバレッジ項目 | 導出元の技法 / 基準 | 期待挙動の根拠 | 優先度 | 備考 |
| --- | --- | --- | --- | --- | --- |

test conditionがないため独立CIは生成していない。

## カバレッジ候補の扱い

| 候補 | 導出元 | 扱い | 理由 / 根拠 | カバー先 |
| --- | --- | --- | --- | --- |
| A | current target disposition | 重複 | `covered_by_target_version`はBのcurrent versionを参照し、BはCI-001へcurrent mapping | B → CI-001 |
| C | current target | ブロック中 | CIに未到達で、current terminal dispositionの根拠も入力にない。このclosure状態は永続Dispositionを作成した意味ではない | — |

## Machine Runtime / Entity / Target mapping（機械証拠）

condition_structure runtimeはbehavioral TR / TCN / model draftがない入力からEntityを生成していない。以下のMachine blocksは空のcondition-structure実行を示す。Target closureの判定は上の提示済みversion・mapping事実に基づく。

### Machine Runtime Input: test-condition-design::artifact:condition_structure:all

```json
{"input":{"inactive_materialize_history":[],"inactive_model_history":[],"inactive_model_keys":[],"inactive_tcn_history":[],"inactive_tcn_ids":[],"models":[],"previous_model_keys":[],"previous_tcn_ids":[],"requirement_dispositions":[],"technique_selections":[],"test_conditions":[],"test_requirements":[],"update_scope_model_keys":[],"update_scope_tcn_ids":[],"zero_scope_terminal":false},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"condition-structure-v2","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:condition_structure:all","scope_key":"all","selection_key":null,"selection_source":null,"skill":"test-condition-design","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```

### Machine Runtime Result: test-condition-design::artifact:condition_structure:all

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:42e5c402944c37254c2f24172ec0029c89fad84df01e6a159dbe89312e7e82a2","generator":"condition_structure","generator_contract_version":"condition-structure-v2","generator_implementation_fingerprint":"sha256:f57c22875c6852befe5825444681e3772c3951d5d1a5f720545c7d2b7f12f3c9","input_fingerprint":"sha256:c47b51668b10d847d81fbb621d1830f16e93ce3921f3d35a6a2cc1b2f58ad7b8","issues":[],"model_fingerprint":null,"model_key":null,"payload":{"active_model_metadata":[],"derived_values":{"entities":[]},"entities":[],"expected_entity_identities":[],"formal_design_summary":null,"inactive_materialize_history":[],"inactive_model_history":[],"inactive_tcn_history":[],"model_key_map":[],"model_key_state":[],"tcn_id_map":[],"tcn_id_state":[],"violations":[]},"result_status":"ready","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"ok","runtime_unit_key":"artifact:condition_structure:all","skill":"test-condition-design","static_data_versions":{},"support_status":"supported","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```

### Machine Entities: test-condition-design

```json
{"entities":[],"schema_version":"entity-state-v2","skill":"test-condition-design"}
```

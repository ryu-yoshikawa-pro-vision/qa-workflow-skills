# 詳細テストケース

## テストケース範囲

- 対象機能: 設定名の保存と設定一覧への表示
- テストレベル: Low-Level Test Case
- 実施環境 / 対象条件: ENV-CHROME-EDITOR。Chromeで更新権限を持つ編集者としてログインできること。対象設定「週次レポート」が存在すること。
- 対象外: 保存成功時のトースト表示（仕様に定義がなく、合否判定に使用しない）
- 仮定 / 未解決事項: TCN-001-CI01はブロック中。提示されたCI Machine Entityのcontent_fingerprintがSkill-local runtimeの検証に一致しない。CI contentにはruntime必須のscope_refsもない。current TCN-001 Machine Entityと、AUTH-SETTING-001のcurrent Authority Machine Entityも入力にないため、根拠のcurrentnessを確認できない。

## テストケース一覧

| テストケースID | タイトル / 目的 | 関連観点ID | 関連カバレッジ項目ID | 関連テスト要求ID | 優先度 | 前提条件 | テストデータ | 実施手順 | 期待結果 | 期待結果の根拠 | 事後状態 / 後処理 | 備考 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## 詳細テストケース完了確認（任意表示）

| テストケースID | 開始者 / 開始状態 | 準備対象 | 操作 | 入力 / 選択 | 合格条件 | 判定 |
| --- | --- | --- | --- | --- | --- | --- |

## テストケースへ展開しないカバレッジ項目 / テスト条件

| 上流ID | 種別 | 扱い | 理由 / 根拠 |
| --- | --- | --- | --- |
| TCN-001-CI01 | カバレッジ項目 | ブロック中 | `case_structure` runtimeが提示CI Entityをcontent_fingerprint不一致で拒否した。CI contentにruntime必須のscope_refsがなく、current TCN-001 Machine EntityおよびAUTH-SETTING-001のcurrent Authority Machine Entityも入力にない。CI Entityの正規版、current TCN Entity、current Authority Entityを解決後、test-case-designで再開する。 |

## Machine Runtime / Entity（機械証拠）

Machine Runtime Resultは入力不備により `runtime_status=invalid_input`、`result_status=blocked`。TCは生成されていない。Machine Entityは生成なし。

### Machine Runtime Input: test-case-design::artifact:case_structure:all

```json
{"input":{"coverage_items":[{"content":{"authority_refs":["AUTH-SETTING-001"],"ci_id":"TCN-001-CI01","covered_targets":[{"execution_fingerprint":"sha256:1d8effe1feb499b0eeb51481c2822e5e0f22f50d0308d06febbbb8b6e3b87285b","target_content_fingerprint":"sha256:447422553fd4116ca4f8b26e66ebcdc0de048a68dbf70a19011b22e88f963579","target_key":"ep:setting-name:valid","target_ref":"sha256:22d41468991f1882b0a1d1573279e27cf2822d64ef1509f73da4e95d25e2c0af"}],"execution":{"action":"save_setting_name","input":{"name":"年次レポート"},"observation":{"settings_list_contains":"年次レポート"},"precondition":{"existing_setting_name":"週次レポート"}},"expected_result_root":"settings-list-contains-new-name","model_key":"ep-001","priority":"中","priority_override_reason":null,"reference_refs":[],"semantic_item_key":null,"semantic_item_text":null,"semantic_source_targets":[],"source_kind":"runtime_target","status":"active","tcn_id":"TCN-001","test_data_requirement_refs":["data:setting-name-valid"]},"content_fingerprint":"sha256:479e6ff6d93ba5b8d7c25fc972ae33ec135a1e4a43b1cbe4a0967bf59a2cede9","entity_ref":"TCN-001-CI01","entity_type":"ci","model_key":"ep-001","runtime_dependencies":[],"schema_version":"entity-state-v2","skill":"test-condition-design","upstream_entity_dependencies":[]}],"dispositions":[],"environment_requirements":[],"inactive_tc_history":[],"inactive_tc_ids":[],"previous_tc_ids":[],"test_cases":[],"test_conditions":[],"test_data_requirements":[{"data_ref":"data:setting-name-valid","dimension_key":"setting_name","operator":"eq","value":{"type":"string","value":"年次レポート"}}],"update_scope_tc_ids":[],"zero_scope_terminal":false},"metadata":{"authority_refs":["AUTH-SETTING-001"],"envelope_version":"1","generator_contract_version":"case-structure-v2","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:case_structure:all","scope_key":null,"selection_key":null,"selection_source":null,"skill":"test-case-design","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```

### Machine Runtime Result: test-case-design::artifact:case_structure:all

```json
{"deterministic_generated":false,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:062d6bc7fd9b9368ccb636228ff077cfacc4d777ed517f06b0ba365bd548ddfd","generator":"case_structure","generator_contract_version":"case-structure-v2","generator_implementation_fingerprint":"sha256:8368255283763a5a2d11ccc14815a644417bfd3f61cf52eeeffb0b3e490f7236","input_fingerprint":"sha256:2a2bfcbb70122045030d340d6d1d2a41dd9bb8b603ce9d30b9092c26d1c087a1","issues":[{"blocking":true,"generation_fingerprint":"sha256:062d6bc7fd9b9368ccb636228ff077cfacc4d777ed517f06b0ba365bd548ddfd","issue_type":"invalid_input","message":"Machine Entity content_fingerprintが不一致です","model_key":null,"runtime_unit_key":"artifact:case_structure:all","skill":"test-case-design","target_key":null}],"model_fingerprint":null,"model_key":null,"payload":{},"result_status":"blocked","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"invalid_input","runtime_unit_key":"artifact:case_structure:all","skill":"test-case-design","static_data_versions":{},"support_status":"unknown","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```

### Machine Entities: test-case-design

```json
{"entities":[],"schema_version":"entity-state-v2","skill":"test-case-design"}
```

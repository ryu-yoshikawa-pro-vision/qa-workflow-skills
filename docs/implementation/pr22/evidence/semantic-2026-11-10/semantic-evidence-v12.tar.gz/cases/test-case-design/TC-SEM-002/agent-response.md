# 詳細テストケース

## テストケース範囲

- 対象機能: 設定名の更新
- テストレベル: 入力に記載なし
- 実施環境 / 対象条件: 更新権限を持つユーザーでログイン済み。対象設定の現在名は「月次レポート」。
- 対象外: エラーメッセージの文言、表示位置、色
- 仮定 / 未解決事項:
  - 入力されたAuthorityの挙動記述は、設定名1〜50文字、51文字以上は保存不可、保存失敗時に設定一覧へ変更を反映しない、の3点。
  - Authorityのcurrent Machine Entity ref / revisionが入力されていないため、提示文を現在有効な仕様根拠へ解決できない。期待結果の根拠を確定できず、対象CIはブロック中。
  - 優先度は入力にない。runtimeのCI schemaに必要な値としてMachine Runtime Inputでは「中」を使用したが、これはケース優先度の決定ではない。

## テストケース一覧

| テストケースID | タイトル / 目的 | 関連観点ID | 関連カバレッジ項目ID | 関連テスト要求ID | 優先度 | 前提条件 | テストデータ | 実施手順 | 期待結果 | 期待結果の根拠 | 事後状態 / 後処理 | 備考 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## テストケースへ展開しないカバレッジ項目 / テスト条件

| 上流ID | 種別 | 扱い | 理由 / 根拠 |
| --- | --- | --- | --- |
| TCN-002-CI01 | カバレッジ項目 | ブロック中 | PASS条件の根拠となるcurrent Authority Machine Entity ref / revisionを解決できない。入力に示されたAuthorityの挙動記述を現行のAuthority Entityへ対応付けられるまでケース化しない。エラー表示仕様はこの項目の対象外。 |

## Machine Runtime / Entity（機械証拠）

### Machine Runtime Input: test-case-design::artifact:case_structure:all

```json
{"input":{"coverage_items":[{"content":{"authority_refs":[],"ci_id":"TCN-002-CI01","execution":null,"model_key":"","priority":"中","scope_refs":[],"semantic_item_key":"TCN-002-CI01","semantic_item_text":"51文字の名称を保存しようとしたとき、保存されず既存名称が維持されること。","semantic_source_targets":[],"source_kind":"semantic_item","tcn_id":"TCN-002","test_data_requirement_refs":[]},"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","model_key":null,"runtime_dependencies":[],"schema_version":"entity-state-v2","skill":"test-condition-design","upstream_entity_dependencies":[]}],"dispositions":[{"authority_refs":[],"covered_by_entity":null,"handling":"ブロック中","reason":"期待結果の根拠となるcurrent Authority Machine Entity ref / revisionが入力されていない。提示されたAuthority文を現在有効なAuthority Entityへ解決できるまで、このカバレッジ項目のケース化をブロックする。エラーメッセージ文言、表示位置、色は未確定のためPASS条件に含めない。","upstream_entity":{"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","skill":"test-condition-design"}}],"environment_requirements":[],"inactive_tc_history":[],"inactive_tc_ids":[],"previous_tc_ids":[],"test_cases":[],"test_conditions":[{"priority":"中","scope_refs":[],"tcn_id":"TCN-002","tr_refs":[]}],"test_data_requirements":[],"update_scope_tc_ids":[],"zero_scope_terminal":false},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"case-structure-v2","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:case_structure:all","scope_key":null,"selection_key":null,"selection_source":null,"skill":"test-case-design","static_data_versions":{},"technique_slug":null,"upstream_entities":[{"content":{"authority_refs":[],"ci_id":"TCN-002-CI01","execution":null,"model_key":"","priority":"中","scope_refs":[],"semantic_item_key":"TCN-002-CI01","semantic_item_text":"51文字の名称を保存しようとしたとき、保存されず既存名称が維持されること。","semantic_source_targets":[],"source_kind":"semantic_item","tcn_id":"TCN-002","test_data_requirement_refs":[]},"entity_ref":"TCN-002-CI01","entity_type":"ci","skill":"test-condition-design"}],"upstream_runtime_units":[]}}
```

### Machine Runtime Result: test-case-design::artifact:case_structure:all

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:c7025de1a2f9dae06b0a1d622ff604f5abc09595237574e7832faa9201083766","generator":"case_structure","generator_contract_version":"case-structure-v2","generator_implementation_fingerprint":"sha256:8368255283763a5a2d11ccc14815a644417bfd3f61cf52eeeffb0b3e490f7236","input_fingerprint":"sha256:947122b7b71cdce879fbb6f06e1b5c22c4eaa08ee0b12ed9fb23ab48022f376f","issues":[],"model_fingerprint":null,"model_key":null,"payload":{"coverage_items":[{"content":{"authority_refs":[],"ci_id":"TCN-002-CI01","execution":null,"model_key":"","priority":"中","scope_refs":[],"semantic_item_key":"TCN-002-CI01","semantic_item_text":"51文字の名称を保存しようとしたとき、保存されず既存名称が維持されること。","semantic_source_targets":[],"source_kind":"semantic_item","tcn_id":"TCN-002","test_data_requirement_refs":[]},"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","model_key":null,"runtime_dependencies":[],"schema_version":"entity-state-v2","skill":"test-condition-design","upstream_entity_dependencies":[]}],"dispositions":[{"authority_refs":[],"covered_by_entity":null,"handling":"ブロック中","reason":"期待結果の根拠となるcurrent Authority Machine Entity ref / revisionが入力されていない。提示されたAuthority文を現在有効なAuthority Entityへ解決できるまで、このカバレッジ項目のケース化をブロックする。エラーメッセージ文言、表示位置、色は未確定のためPASS条件に含めない。","upstream_entity":{"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","skill":"test-condition-design"}}],"entities":[{"content":{"authority_refs":[],"covered_by_entity":null,"handling":"ブロック中","reason":"期待結果の根拠となるcurrent Authority Machine Entity ref / revisionが入力されていない。提示されたAuthority文を現在有効なAuthority Entityへ解決できるまで、このカバレッジ項目のケース化をブロックする。エラーメッセージ文言、表示位置、色は未確定のためPASS条件に含めない。","upstream_entity":{"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","skill":"test-condition-design"}},"content_fingerprint":"sha256:382fa6e723aee9159194ced7623aa9b2a3ee8c6d9dda5d5c10e58427e7c82076","entity_ref":"ci:TCN-002-CI01","entity_type":"disposition","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:96349e28875c13f89c10813a4ffb0dcc71f56e2ca010862ca06960f522a0c428","runtime_unit_key":"artifact:case_structure:all#entity:sha256:e2cf53835003bed4f06df7568a9135e6c8343986609dc945ff9ce21d02d91270","skill":"test-case-design"}],"schema_version":"entity-state-v2","upstream_entity_dependencies":[{"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","skill":"test-condition-design"}]}],"environment_requirements":[],"expected_entity_identities":[{"entity_ref":"ci:TCN-002-CI01","entity_type":"disposition","skill":"test-case-design"}],"inactive_tc_history":[],"tc_id_map":[],"tc_id_state":[],"test_cases":[],"test_conditions":[{"priority":"中","scope_refs":[],"tcn_id":"TCN-002","tr_refs":[]}],"test_data_requirements":[],"violations":[]},"result_status":"ready","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"ok","runtime_unit_key":"artifact:case_structure:all","skill":"test-case-design","static_data_versions":{},"support_status":"supported","upstream_entity_fingerprints":[{"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","skill":"test-condition-design"}],"upstream_runtime_units":[]}
```

### Machine Entities: test-case-design

```json
{"entities":[{"content":{"authority_refs":[],"covered_by_entity":null,"handling":"ブロック中","reason":"期待結果の根拠となるcurrent Authority Machine Entity ref / revisionが入力されていない。提示されたAuthority文を現在有効なAuthority Entityへ解決できるまで、このカバレッジ項目のケース化をブロックする。エラーメッセージ文言、表示位置、色は未確定のためPASS条件に含めない。","upstream_entity":{"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","skill":"test-condition-design"}},"content_fingerprint":"sha256:382fa6e723aee9159194ced7623aa9b2a3ee8c6d9dda5d5c10e58427e7c82076","entity_ref":"ci:TCN-002-CI01","entity_type":"disposition","model_key":null,"runtime_dependencies":[{"generation_fingerprint":"sha256:96349e28875c13f89c10813a4ffb0dcc71f56e2ca010862ca06960f522a0c428","runtime_unit_key":"artifact:case_structure:all#entity:sha256:e2cf53835003bed4f06df7568a9135e6c8343986609dc945ff9ce21d02d91270","skill":"test-case-design"}],"schema_version":"entity-state-v2","upstream_entity_dependencies":[{"content_fingerprint":"sha256:f9ffb47ca6569deb78df95c1714574640c1355a8a5aefc985c76e3ce8c7c3d92","entity_ref":"TCN-002-CI01","entity_type":"ci","skill":"test-condition-design"}]}],"schema_version":"entity-state-v2","skill":"test-case-design"}
```
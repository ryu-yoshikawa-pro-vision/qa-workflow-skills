# カバレッジ分析

- 対象 / 実行範囲: テスト設計（Authority → QA ID graph closure） / TC → E2E実装 / E2E実装 → 実行結果

## カバレッジ範囲

- モード: 部分分析
- 情報源基準: 評価入力に記載されたAuthority 2件、TC → E2E対応、実行状況のみ。Authorityの改訂・現行性は未提示。
- 対象成果物層: Authority → テスト要求の閉鎖、参照されたTC → E2E実装、E2E実装参照 → 実行結果または未実行理由。
- 対象バージョン / 機能: 注文履歴表示、対象注文の明細表示。バージョン未提示。
- 対象外: 実装ファイル内容・テスト手順・assertion、TR/TCN/CI/TC成果物本文、リスク評価、技法別カバレッジ基準、実行結果のPASS/FAIL内容。
- 鮮度制約: 全成果物にrevision / timestampがなく、currentnessは確認できない。`current`の証拠として昇格しない。

## 仕様根拠 / プロダクトリスクの閉鎖状況

| 上流ID | 種別 | 接続先テスト要求 / 扱い | 状態 | 根拠 / ギャップ |
| ------ | ---- | ----------------------- | ---- | --------------- |
| TC-101 | Authority | TR / 明示した扱いなし | 判定不能（未閉鎖） | 「ログイン後に注文履歴を表示」の記述はあるが、現行性の根拠がなく、TR参照または扱いも入力にない。 |
| TC-102 | Authority | TR / 明示した扱いなし | 判定不能（未閉鎖） | 「詳細を開くと対象注文の明細を表示」の記述はあるが、現行性の根拠がなく、TR参照または扱いも入力にない。 |
| — | プロダクトリスク | 入力なし | 判定不能 | リスク項目・優先度・深度情報がない。リスクなしとは判断しない。 |

同じ文字列の`TC-101` / `TC-102`がAuthority IDとTC参照の両方に現れる。入力上の種別を保ち、ID文字列だけから同一Entityや直接リンクを推定しない。

## カバレッジ基準確認

| 観点ID | Model Key | 適用技法 / 構造 | カバレッジ基準 | 必要な項目数 / 範囲 | 充足状況 | 根拠 / ギャップ |
| ------ | --------- | --------------- | -------------- | ------------------- | -------- | --------------- |
| — | — | 入力なし | 入力なし | 候補母集団なし | 判定不能 | 技法・基準・条件・coverage itemがないため、技法別coverageの充足率は判定しない。基準を補作しない。 |

## 正式設計候補coverage（入力にある場合）

入力なし。正式設計候補、record、item × condition分母の判定対象なし。

この局所record検証は保存先のcurrentness・承認・CAS・readbackの証明ではありません。正式設計候補coverageをCI／QA artifact graphの件数へ加算しません。

## カバレッジ候補の扱い確認

| 候補 | 導出元 | 扱い | 妥当性 | 根拠 / ギャップ | 修正Skill |
| ---- | ------ | ---- | ------ | --------------- | --------- |
| 対象候補なし | — | 入力なし | 判定不能 | 候補集合・扱い情報なし。 | `test-condition-design`（候補が設計対象なら） |

## カバレッジ項目の扱い

| カバレッジ項目ID / 項目 | Model Key | 観点ID | 扱い | 対応テストケースID / 扱い | 根拠 / 備考 |
| ----------------------- | --------- | ------- | ---- | ------------------------- | ----------- |
| 入力なし | — | — | 判定不能 | 入力なし | CI / coverage item / TC設計成果物がないため、扱いを推定しない。 |

## カバレッジマトリクス

| 上流層 | 上流ID / 挙動 | 下流層 | 下流ID / 扱い | カバレッジ | プロダクトリスク / 優先度 | 根拠 / ギャップ | 推奨対応 | 修正Skill / 層 |
| ------ | ------------- | ------ | ------------- | ---------- | ------------------------- | --------------- | -------- | -------------- |
| Authority | TC-101: ログイン後に注文履歴を表示 | テスト要求 | TR参照なし / 扱いなし | 未網羅（提供範囲） | 未評価 | TR ID・リンク・扱い情報がない。Authorityのcurrentnessも未確認。 | Authorityの現行性を確定し、必要なTRまたは妥当な扱いを記録する。 | `spec-analysis` → `test-requirement-design` |
| Authority | TC-102: 詳細を開くと対象注文の明細を表示 | テスト要求 | TR参照なし / 扱いなし | 未網羅（提供範囲） | 未評価 | TR ID・リンク・扱い情報がない。Authorityのcurrentnessも未確認。 | Authorityの現行性を確定し、必要なTRまたは妥当な扱いを記録する。 | `spec-analysis` → `test-requirement-design` |
| QA graph | TR → TCN → CI → TC | 下流QA成果物 | TR / TCN / CI / TC本文・edgeなし | 未網羅（成果物未提示） | 未評価 | TC IDを含むE2E対応はQA graphの上流edgeやcase本文の代替にならない。 | TR確定後、条件・基準・coverage item・TCをそれぞれの責任層で追跡する。 | `test-requirement-design` → `test-condition-design` → `test-case-design` |

## 全体チェーン概要

| リンク | 状態 | 重大ギャップ / 備考 |
| ------ | ---- | ------------------- |
| 現在有効な仕様根拠 ↔ テスト要求 | 判定不能 / 提供範囲では未閉鎖 | Authorityの現行性未確認、TRも扱いもない。 |
| プロダクトリスク ↔ テスト要求 | 判定不能 | リスク入力なし。 |
| テスト要求 ↔ テスト条件 | 未網羅 / 判定不能 | TR・TCN入力なし。 |
| テスト条件 ↔ カバレッジ項目（明示時） | 判定不能 | 条件・CI入力なし。 |
| カバレッジ項目 ↔ テストケース（明示時） | 判定不能 | coverage item・TC設計入力なし。 |
| テスト条件 ↔ テストケース（内包時） | 判定不能 | 条件・TC本文入力なし。 |

## 重複 / 統合分析

| 成果物ID | 分類 | 理由 | 推奨対応 | 修正Skill / 層 |
| -------- | ---- | ---- | -------- | -------------- |
| — | 判定材料不足 | 2件の意味は一覧表示と対象明細表示で異なるが、TC手順・assertion本文がないため実質重複の有無は確定できない。 | TC本文を照合する。 | `test-case-design` |

## 陳腐化 / 孤立分析

| 成果物ID | Model Key | 分類 | 現在の根拠 | 問題 | 推奨対応 | 修正Skill / 層 |
| -------- | --------- | ---- | ---------- | ---- | -------- | -------------- |
| Authority TC-101 / TC-102 | — | 要再検証 | 評価入力のみ | 現行revision / currentnessがない。 | Authorityの現行性とID種別を確認する。 | `spec-analysis` |
| TC-101 / TC-102（TC種別） | — | 孤立（提供graph内） | E2E対応行にTC参照あり | graph上のTR / TCN / CIからのedge、TC本文がない。E2E参照はgraph node / edgeに混入していない。 | 上流QA ID graphとTC成果物を復元・照合する。 | `test-requirement-design` / `test-condition-design` / `test-case-design` |

## 優先度別ギャップ

| 優先度 | ギャップ | 影響する上流ID | 推奨対応 | 修正Skill / 層 |
| ------ | -------- | -------------- | -------- | -------------- |
| 判定不能 | Authority現行性とTR閉鎖が不明 | TC-101, TC-102 | 現行Authorityを確定し、TRまたは扱いへ閉じる。 | `spec-analysis` / `test-requirement-design` |
| 判定不能 | TR / TCN / CI / TCのgraph閉鎖を確認できない | TC-101, TC-102 | 各QA成果物・edgeを入力して照合する。 | `test-requirement-design` / `test-condition-design` / `test-case-design` |
| 判定不能 | `result-1`の実行結果内容がない | TC-101 | PASS/FAIL等の記録と参照を提示する。 | `e2e-test-execution` |
| 判定不能 | order detailは未実行で環境到達性の確認待ち | TC-102 | 到達性を確認し、実行結果または更新された未実行理由を記録する。 | `e2e-test-execution` |

リスク採点・優先度がないため、高 / 中 / 低の順位を割り当てない。

## TC → E2E実装対応表（対象がTC → E2E実装の場合）

| TC ID | 扱い | E2E実装参照 | 根拠 / 備考 |
| ------ | ---- | ----------- | ----------- |
| TC-101 | 既存E2E再利用（入力上の対応） | `tests/orders/order.spec.ts > order history` | TC対応の明示あり。タイトルは履歴表示と意味的に整合するが、実装・手順・assertionは未確認。 |
| TC-102 | 既存E2E再利用（入力上の対応） | `tests/orders/order.spec.ts > order detail` | TC対応の明示あり。タイトルは注文詳細と意味的に整合するが、対象注文との一致確認を含むかは未確認。 |

この表はTC → E2Eの対応のみを扱う。E2E参照を既存QA ID graphのnode / edgeとして追加していない。

## E2E実装 → 実行結果追跡

| E2E実装参照 | 解決されたTC参照 | 実行状態 | 実行結果参照 | 結果 / 未実行理由 | 追跡状況 |
| ------------ | ----------------- | -------- | ------------ | ------------------ | -------- |
| `tests/orders/order.spec.ts > order history` | TC-101（対応記述上） | 実行済み | `result-1` | 実行結果の値・判定は未提示。 | 実行参照はあるが結果値・判定は不明。PASS / FAILの実行証拠としては未閉鎖。 |
| `tests/orders/order.spec.ts > order detail` | TC-102（対応記述上） | 未実行 | なし | 環境到達性の確認が必要。 | 未実行理由は明示。実行coverageはなし。到達性確認後の結果は未閉鎖。 |

## 残存リスク / ブロック中

- **QA graphのcurrent closureはブロック中**: Authorityのrevision / currentnessを確認できず、現在有効な上流集合を確定できない。提供された2件の範囲内ではTRまたは扱いがなく未閉鎖である。currentness不明を完全カバレッジへ昇格しない。
- **技法別coverageは判定不能**: coverage基準・候補母集団・条件・coverage itemがない。今回の部分的な対応表・実行traceから技法coverageを推定しない。
- `result-1`は実行済み参照のみで結果値がなく、order detailは未実行。いずれもPASS/FAILやテスト合格の証拠ではない。
- 実装ソースは提供されておらず、参照文字列を越えたE2E動作・期待結果の根拠は確認していない。

## Machine Runtime / Entity（機械証拠）

以下の`traceability` runtimeは、提供されたQA graph projectionだけを検査する。`Authority:`接頭辞は、同じID文字列をAuthority型とTC型で区別するためのローカルnode keyで、新しいQA IDではない。`analysis_scopes`は空で、担当Skill verifier由来のcurrent structure state / currentness証拠はない。`can_complete=false`とgraph issueはこの局所入力の未閉鎖を示し、全体coverage判定やE2E結果を代替しない。E2E対応・実行traceは別表で保持している。

- Expected runtime unit: `coverage-analysis::artifact:traceability:all`
- Machine Entities: `coverage-analysis`のEntityなし（この入力からの期待数 0）
- Runtime status: `ok`; result status: `unresolved`; `can_complete: false`

### Machine Runtime Input: coverage-analysis::artifact:traceability:all

```json
{"input":{"analysis_scopes":[],"current_entities":[],"current_runtime_units":[],"dispositions":[],"edges":[],"nodes":[{"node_key":"Authority:TC-101","node_type":"Authority"},{"node_key":"Authority:TC-102","node_type":"Authority"},{"node_key":"TC-101","node_type":"TC"},{"node_key":"TC-102","node_type":"TC"}],"runtime_units":[],"unsupported_item_closures":[]},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"traceability-v1","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:traceability:all","scope_key":"all","selection_key":null,"selection_source":null,"skill":"coverage-analysis","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```

### Machine Runtime Result: coverage-analysis::artifact:traceability:all

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:de8eeb10214d76f34132705b8bab235297197ae13b4317b6a0db5ad01e647de8","generator":"traceability","generator_contract_version":"traceability-v1","generator_implementation_fingerprint":"sha256:884cfeecc7d52239cfe998e71926cafb3cc68f5ede5a073ab0818928effabb5b","input_fingerprint":"sha256:2ac34b6046201f4595ae9795b7ecec710e963eed0284978a6e63954cce9cc556","issues":[{"blocking":true,"generation_fingerprint":"sha256:de8eeb10214d76f34132705b8bab235297197ae13b4317b6a0db5ad01e647de8","issue_type":"missing_ci_edge","model_key":null,"node_key":"TC-101","runtime_unit_key":"artifact:traceability:all","skill":"coverage-analysis","target_key":null},{"blocking":true,"generation_fingerprint":"sha256:de8eeb10214d76f34132705b8bab235297197ae13b4317b6a0db5ad01e647de8","issue_type":"missing_ci_edge","model_key":null,"node_key":"TC-102","runtime_unit_key":"artifact:traceability:all","skill":"coverage-analysis","target_key":null},{"blocking":true,"generation_fingerprint":"sha256:de8eeb10214d76f34132705b8bab235297197ae13b4317b6a0db5ad01e647de8","issue_type":"orphan_node","model_key":null,"node_key":"TC-101","node_type":"TC","runtime_unit_key":"artifact:traceability:all","skill":"coverage-analysis","target_key":null},{"blocking":true,"generation_fingerprint":"sha256:de8eeb10214d76f34132705b8bab235297197ae13b4317b6a0db5ad01e647de8","issue_type":"orphan_node","model_key":null,"node_key":"TC-102","node_type":"TC","runtime_unit_key":"artifact:traceability:all","skill":"coverage-analysis","target_key":null}],"model_fingerprint":null,"model_key":null,"payload":{"analysis_scopes":[],"can_complete":false,"current_entities":[],"dispositions":[],"edges":[],"entity_freshness":[],"expected_entities":[],"expected_runtime_units":[],"extra_entities":[],"extra_runtime_units":[],"formal_design_metrics":[],"missing_entities":[],"missing_runtime_units":[],"nodes":[{"node_key":"Authority:TC-101","node_type":"Authority"},{"node_key":"Authority:TC-102","node_type":"Authority"},{"node_key":"TC-101","node_type":"TC"},{"node_key":"TC-102","node_type":"TC"}],"runtime_freshness":[],"runtime_units":[],"unsupported_item_closures":[]},"result_status":"unresolved","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"ok","runtime_unit_key":"artifact:traceability:all","skill":"coverage-analysis","static_data_versions":{},"support_status":"supported","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```

### Machine Entities: coverage-analysis

```json
{"entities":[],"schema_version":"entity-state-v2","skill":"coverage-analysis"}
```
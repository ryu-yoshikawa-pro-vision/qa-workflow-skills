# カバレッジ分析

- 対象 / 実行範囲: テスト設計（RISK-001 → TR-001 → TCN-001 / TCN-002 → TC-001 / TC-002）

## カバレッジ範囲

- モード: 部分
- 情報源基準: ユーザー提供の Eval Input のみ。現行仕様文書や上流Skill成果物は提示されていない。
- 対象成果物層: Product Risk、Test Requirement、Test Condition、Test Case、および提示されたcoverage matrixの経路
- 対象バージョン / 機能: バージョン指定なし。externalユーザーによるprivate会話の閲覧制御
- 対象外: 仕様集合の網羅的解決、正式なリスク採点、技法固有coverage基準、正式設計候補母集団、E2E実装・実行結果
- 鮮度制約: revision / currentness情報なし。判定は提示文の意味に限る。

## 仕様根拠 / プロダクトリスクの閉鎖状況

| 上流ID | 種別 | 接続先テスト要求 / 扱い | 状態 | 根拠 / ギャップ |
| ------ | ---- | ----------------------- | ---- | --------------- |
| RISK-001 | プロダクトリスク | TR-001 | 部分 | 「roleとvisibilityに応じた閲覧可否」はリスクの主題に対応する。一方、external＋privateを拒否する条件と期待結果がTR / 下流ケースで明示されていない。 |
| — | 仕様根拠 | — | 判定不能 | 現行仕様のID・本文・revisionが入力にないため、仕様根拠からの閉鎖および期待結果の現行性は確認できない。 |

## カバレッジ基準確認

| 観点ID | Model Key | 適用技法 / 構造 | カバレッジ基準 | 必要な項目数 / 範囲 | 充足状況 | 根拠 / ギャップ |
| ------ | --------- | --------------- | -------------- | ------------------- | -------- | --------------- |
| TCN-001 | 指定なし | 指定なし | 未提示 | 未提示 | 判定不能 | 条件はowner＋privateの許可。技法、候補母集団、基準がなく、基準充足率は判定しない。 |
| TCN-002 | 指定なし | 指定なし | 未提示 | 未提示 | 判定不能 | 条件はexternal＋publicの許可。これはRISK-001のexternal＋private拒否を代替しない。 |

正式な技法別coverageの十分性は判定不能。基準・候補母集団・扱いの定義は `test-condition-design` へ戻す。

## カバレッジ候補の扱い確認

| 候補 | 導出元 | 扱い | 妥当性 | 根拠 / ギャップ | 修正Skill |
| ---- | ------ | ---- | ------ | --------------- | --------- |
| 候補母集団は未提示 | Eval Input | 候補別の採用 / 除外 / その他の扱いなし | 判定不能 | 個々の候補や扱いがないため妥当性を評価できない。候補集合を推測して補わない。 | test-condition-design |

## カバレッジ項目の扱い

| カバレッジ項目ID / 項目 | Model Key | 観点ID | 扱い | 対応テストケースID / 扱い | 根拠 / 備考 |
| ----------------------- | --------- | ------- | ---- | ------------------------- | ----------- |
| 明示CI項目なし | — | TCN-001 / TCN-002 | TCN内包のTCへ直接記載 | TC-001 / TC-002 | 独立CI一覧はない。TCN→TCの直接記載で意味を確認し、CI IDや候補を創作しない。 |

## カバレッジマトリクス

| 上流層 | 上流ID / 挙動 | 下流層 | 下流ID / 扱い | カバレッジ | プロダクトリスク / 優先度 | 根拠 / ギャップ | 推奨対応 | 修正Skill / 層 |
| ------ | ------------- | ------ | ------------- | ---------- | ------------------------- | --------------- | -------- | -------------- |
| Product Risk | RISK-001: externalがprivate会話を閲覧すると機密情報が露出 | Test Requirement | TR-001 | 部分網羅 | 正式採点なし | role / visibility別の閲覧可否という主題は対応するが、拒否すべき組合せが明示されていない。 | 現行仕様でexternal＋privateの期待結果を確認し、要求へ明示する。 | spec-analysis / question-analysis、必要ならtest-requirement-design |
| TR | TR-001: roleとvisibilityに応じた閲覧可否 | Test Condition | TCN-001 | 部分網羅 | 正式採点なし | owner＋privateの許可を確認する。正当な所有者のpositive pathであり、外部ユーザーの拒否責務は検証しない。 | private会話の拒否境界を別条件として定義する。 | test-condition-design |
| TR | TR-001: roleとvisibilityに応じた閲覧可否 | Test Condition | TCN-002 | 部分網羅 | 正式採点なし | external＋publicの許可を確認する。公開閲覧のpositive pathで、private閲覧拒否の証拠ではない。 | リスク対象のexternal＋private条件を追加する。 | test-condition-design |
| Test Condition | TCN-001: owner＋private → 閲覧可能 | Test Case | TC-001 | 部分網羅 | 正式採点なし | 対象条件と期待動作は読み取れるが、現行仕様根拠への参照と実行可能な手順 / 観測点は示されていない。 | 期待結果の根拠を確認し、実施可能な確認手順・判定点を記す。 | question-analysis / test-case-design |
| Test Condition | TCN-002: external＋public → 閲覧可能 | Test Case | TC-002 | 部分網羅 | 正式採点なし | externalのpositive pathとしては読めるが、private対象ではない。現行仕様根拠も提示されていない。 | public許可の仕様根拠を確認し、実施可能な判定点を記す。 | question-analysis / test-case-design |
| Product Risk | RISK-001: external＋privateでの機密露出 | Test Case | TC-001 / TC-002 | 未網羅 | 正式採点なし（機密漏えいリスクの記載あり） | TC-001はowner＋private許可、TC-002はexternal＋public許可。どちらもexternal＋private拒否を検証しない。提示matrixのID接続だけではこの意味上の欠落は埋まらない。 | 期待結果の権威ある根拠を確認後、条件と否定ケースを設計する。 | spec-analysis / question-analysis → test-condition-design → test-case-design |

テストケースの最低限の意味は識別できるが、提示された一行記述だけでは実施可能なセットアップ / 操作 / 観測点と、現行仕様に基づく合否根拠を確認できない。ケースを完全なcoverage証拠としては数えない。

## 全体チェーン概要

| リンク | 状態 | 重大ギャップ / 備考 |
| ------ | ---- | ------------------- |
| 現在有効な仕様根拠 ↔ テスト要求 | 判定不能 | 現行仕様とrevisionが未提示。 |
| プロダクトリスク ↔ テスト要求 | 部分 | RISK-001とTR-001の主題は対応するが、external＋private拒否の具体条件が未明示。 |
| テスト要求 ↔ テスト条件 | 部分 | owner＋private許可、external＋public許可の2条件はある。リスク該当のexternal＋private拒否条件がない。 |
| テスト条件 ↔ カバレッジ項目（明示時） | 判定不能 / 該当情報なし | 明示CI項目・候補母集団なし。TCN内包ケースへの直接経路を確認。 |
| カバレッジ項目 ↔ テストケース（明示時） | 該当なし | 独立CI項目は提示されていない。 |
| テスト条件 ↔ テストケース（内包時） | 部分 | 各TCNにケースが記載されているが、TC-001 / TC-002ともRISK-001の拒否境界を検証しない。 |

## 重複 / 統合分析

| 成果物ID | 分類 | 理由 | 推奨対応 | 修正Skill / 層 |
| -------- | ---- | ---- | -------- | -------------- |
| 該当なし | — | owner＋private許可とexternal＋public許可は異なるpositive pathで、同一責務の重複とは判断できない。 | — | — |

## 陳腐化 / 孤立分析

| 成果物ID | Model Key | 分類 | 現在の根拠 | 問題 | 推奨対応 | 修正Skill / 層 |
| -------- | --------- | ---- | ---------- | ---- | -------- | -------------- |
| TC-001 / TC-002 | — | 要再検証 | 期待結果の現行仕様参照・revisionが未提示 | 指定された許可結果が現在有効な仕様と一致するか検証できず、合否根拠として閉じていない。陳腐化と断定はしない。 | 現行仕様参照を確定し、条件と期待結果の根拠を結ぶ。 | spec-analysis / question-analysis、test-case-design |

## 優先度別ギャップ

| 優先度 | ギャップ | 影響する上流ID | 推奨対応 | 修正Skill / 層 |
| ------ | -------- | -------------- | -------- | -------------- |
| 未採点・要優先確認 | external＋private拒否のケースがなく、RISK-001の機密露出経路を直接確認できない。正式なリスク点数は入力にない。 | RISK-001 | 期待結果の現行根拠を確定し、条件・coverage基準・ケースを追加する。 | spec-analysis / question-analysis → test-condition-design → test-case-design |
| 未採点 | カバレッジ基準、候補集合、扱い情報がなく、正式な基準充足を評価できない。 | TR-001 | 技法・母集団・基準・候補の扱いを明示する。 | test-condition-design |
| 未採点 | TCの期待結果に現行仕様参照と実行可能な判定点がない。 | TR-001 | 根拠を結び、操作と観測可能な合否条件を記す。 | question-analysis / test-case-design |

リスク採点は行っていない。記載された機密漏えいリスクに対して、直接検証ケースが欠けているという設計深度上の不足を確認した。

## 残存リスク / ブロック中

- 残存リスク: externalユーザーによるprivate会話閲覧を許す欠陥が、提示ケースでは検出されない可能性がある。
- 本部分分析: 意味上の不一致と未カバー箇所を確認できたため、分析自体はブロック中ではない。
- 未解決 / 判定不能: 現行仕様、正式coverage基準、候補母集団、上流Skillのcurrent structure evidenceがないため、全体設計の閉鎖性・基準充足・期待結果のcurrentnessは確定できない。正式基準の十分性を扱う範囲は `test-condition-design` の入力待ち。
- 実行結果: テスト実行結果は入力されていない。実装・実行済みとは扱わない。

## Machine Runtime / Entity（機械証拠）

- `traceability` runtime unit: `artifact:traceability:all`（Skill-local dispatchから導出）
- 入力グラフ: 提供されたRisk / TR / TCN / TCとその記載関係を正規化。analysis scope配列は空で、担当Skill verifier由来の`current_structure_state`は入力されていないため、現在有効な上流Runtime / Entity証拠は含めていない。
- 結果: `runtime_status=ok`、`result_status=unresolved`、`can_complete=false`、graph issueなし。ローカル構造グラフのissueなしという結果は、意味上のRISK-001 coverage、仕様currentness、正式基準充足を証明しない。
- Machine Entity / current runtime row: なし。coverage-analysis自身のEntityをcarry-forwardしていない。

### Machine Runtime Input: coverage-analysis::artifact:traceability:all

```json
{"input":{"analysis_scopes":[],"current_entities":[],"current_runtime_units":[],"dispositions":[],"edges":[{"from":"RISK-001","to":"TR-001"},{"from":"TR-001","to":"TCN-001"},{"from":"TR-001","to":"TCN-002"},{"from":"TCN-001","to":"TC-001"},{"from":"TCN-002","to":"TC-002"}],"nodes":[{"node_key":"RISK-001","node_type":"Risk"},{"node_key":"TR-001","node_type":"TR"},{"node_key":"TCN-001","node_type":"TCN"},{"node_key":"TCN-002","node_type":"TCN"},{"node_key":"TC-001","node_type":"TC"},{"node_key":"TC-002","node_type":"TC"}],"runtime_units":[],"unsupported_item_closures":[]},"metadata":{"authority_refs":[],"envelope_version":"1","generator_contract_version":"traceability-v1","input_mode":"direct","model_key":null,"model_type":null,"reference_refs":[],"runtime_contract_version":"runtime-v2","runtime_unit_key":"artifact:traceability:all","scope_key":"all","selection_key":null,"selection_source":null,"skill":"coverage-analysis","static_data_versions":{},"technique_slug":null,"upstream_entities":[],"upstream_runtime_units":[]}}
```

### Machine Runtime Result: coverage-analysis::artifact:traceability:all

```json
{"deterministic_generated":true,"envelope_version":"1","fallback_reason":null,"generation_fingerprint":"sha256:05de4819866a25e919a2b22faec4cc04d7bcd626ddaf8d5eda0c91fac7330298","generator":"traceability","generator_contract_version":"traceability-v1","generator_implementation_fingerprint":"sha256:884cfeecc7d52239cfe998e71926cafb3cc68f5ede5a073ab0818928effabb5b","input_fingerprint":"sha256:cabccbf6d6bea3c0f81f3c63778f547d9e44cf07f4e70730121610ab3f7966d0","issues":[],"model_fingerprint":null,"model_key":null,"payload":{"analysis_scopes":[],"can_complete":false,"current_entities":[],"dispositions":[],"edges":[{"from":"RISK-001","to":"TR-001"},{"from":"TCN-001","to":"TC-001"},{"from":"TCN-002","to":"TC-002"},{"from":"TR-001","to":"TCN-001"},{"from":"TR-001","to":"TCN-002"}],"entity_freshness":[],"expected_entities":[],"expected_runtime_units":[],"extra_entities":[],"extra_runtime_units":[],"formal_design_metrics":[],"missing_entities":[],"missing_runtime_units":[],"nodes":[{"node_key":"RISK-001","node_type":"Risk"},{"node_key":"TC-001","node_type":"TC"},{"node_key":"TC-002","node_type":"TC"},{"node_key":"TCN-001","node_type":"TCN"},{"node_key":"TCN-002","node_type":"TCN"},{"node_key":"TR-001","node_type":"TR"}],"runtime_freshness":[],"runtime_units":[],"unsupported_item_closures":[]},"result_status":"unresolved","runtime_contract_version":"runtime-v2","runtime_implementation_fingerprint":"sha256:27f0719bbcd3b8f3543c1036b4e0bb5188988c8a2f4722f748b22412ca868f8f","runtime_required":true,"runtime_status":"ok","runtime_unit_key":"artifact:traceability:all","skill":"coverage-analysis","static_data_versions":{},"support_status":"supported","upstream_entity_fingerprints":[],"upstream_runtime_units":[]}
```

### Machine Entities: coverage-analysis

```json
{"entities":[],"schema_version":"entity-state-v2","skill":"coverage-analysis"}
```

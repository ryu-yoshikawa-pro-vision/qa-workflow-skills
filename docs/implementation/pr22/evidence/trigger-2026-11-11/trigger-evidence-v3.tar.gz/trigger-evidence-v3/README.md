# Trigger evidence v3 — full repository snapshot, E2E train query 1

- Source HEAD: `d63b5588956b767c4ffac300c34ab0f30798c70a` (the repository state used to build the full-tree snapshot).
- Codex CLI: `0.167.0`; each attempt used a fresh `codex exec`, read-only sandbox, and the exact dataset query.
- Environment: all 24 current Skill packages, 1,051 package files, no hash mismatches, no name collisions with pre-existing Codex skills; full tracked repository files were present. The manifest is included.
- Dataset: `e2e-test-selection/evals/trigger/train_queries.json`, index 0, exact query preserved. Dataset SHA-256: `1a3d7e7236d2c865bbe6cf2477b78fd4bbcdbfc12f6cd84318fa54fdf945ee01`.
- Attempts: 3/3 completed; each exit 0 and `turn.completed`; target Skill read observed 3/3; trigger rate 1.0, above the required `> 0.5` for this positive query. This is one query only, not a dataset-level result.
- Secondary read: `qa-workflow` was read in attempt 1 when the Agent examined the repo orchestration contract; other attempts did not read it. This single observation is retained for routing review and is not assigned an unexpected-trigger verdict without the full matrix.
- All three raw JSONL traces, responses, stderr, exact query, dataset pointer, and parsed event summaries are included. Answer text is not used as trigger evidence.
- The earlier v1/v2 runs were on a reduced snapshot and remain preliminary only.

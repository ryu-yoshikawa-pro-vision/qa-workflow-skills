# Trigger evidence v4 — E2E train negative query 2

- Source HEAD `d63b5588956b767c4ffac300c34ab0f30798c70a`; Codex CLI `0.167.0`.
- Full tracked repository snapshot with 24 current Skills and 1,051 Skill package files available simultaneously; 0 package hash mismatches and 0 existing Skill-name collisions.
- Exact `e2e-test-selection` train query index 1, three independent fresh Codex exec sessions. All attempts exit 0 and `turn.completed`.
- `e2e-test-selection` Skill read: 0/3; `e2e-test-execution` Skill read: 3/3. Thus target trigger rate 0.0 meets the negative `<0.5` threshold for this query only.
- Raw JSONL, responses, stderr, query, result metadata, and source package manifest are included.

## 決定

**Locator はユーザーに見える意味を優先し、fixture はテスト単位で必要なものだけ用意する**方針にします。

### Locator

- 操作対象は `getByRole('button', { name: '保存', exact: true })` のように、role と accessible name で特定します。
- 入力欄は `getByLabel()`、画面上の文言確認は `getByText()` を使います。
- 同じ要素が複数ある場合は、カードや行などの親を `filter()` で絞ってから操作します。`nth()` や長い CSS / XPath で順番・DOM 構造に依存させません。
- 適切な意味的 locator がない対象には、安定した `data-testid` と `getByTestId()` を使います。role や label の確認自体がテスト対象なら、test id でその欠陥を隠さないようにします。
- 固定時間待機は使わず、Playwright の自動待機と `expect` の再試行に任せます。

Playwright も role・text・明示的な test id を優先し、CSS / XPath は壊れやすい選択肢として案内しています。[Locator ガイド](https://playwright.dev/docs/locators)・[Best Practices](https://playwright.dev/docs/best-practices)

### Fixture

- 通常は組み込みの `{ page }` / `{ context }` を使います。
- 複数テストで共有する前提準備やページオブジェクトがある場合だけ、機能単位の fixture を `test.extend()` で定義します。1テストだけの準備はテスト内に残します。
- fixture は既定のテストスコープとし、作成したデータやリソースの後片付けも同じ fixture に置きます。変更可能なデータを worker 間で共有しません。
- 汎用 fixture フレームワークは追加せず、既存構成があればそれを再利用します。

この形で fixture を定義します。`CatalogPage` と `goto()` は形を示す例で、実在の画面名や経路を示すものではありません。

```ts
import { test as base, expect } from '@playwright/test';
import { CatalogPage } from './pages/catalog-page';

type Fixtures = { catalogPage: CatalogPage };

export const test = base.extend<Fixtures>({
  catalogPage: async ({ page }, use) => {
    const catalogPage = new CatalogPage(page);
    await catalogPage.goto();
    await use(catalogPage);
  },
});

export { expect };
```

Playwright の fixture はテストごとに分離され、必要なものだけ遅延して使えます。[Fixtures ガイド](https://playwright.dev/docs/test-fixtures)

この workspace には `.agents/skills` と manifest しかなく、アプリ本体・Playwright 設定・既存 spec は確認できませんでした。ファイルも読み取り専用のため、これは実装方針の決定です。既存構成への組み込みはまだ行っていません。ローカルの [E2E 実装 Skill](/tmp/pr27-trigger-eval-snapshot-fc1478d2/.agents/skills/e2e-test-implementation/SKILL.md) に沿い、実装時は既存の fixture・helper・locator 方針を優先します。
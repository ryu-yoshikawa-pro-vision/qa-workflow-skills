## 決定案

- **locator:** 操作要素は `getByRole(role, { name })`、入力欄は `getByLabel()`、説明文などは `getByText()` を基本にします。重複する要素は dialog・list などの親から絞り込みます。ユーザー向けの意味で一意に特定できない場合だけ、安定した `data-testid` を使います。長いCSS/XPathや、順序が仕様でない要素への `.nth()` は避けます。Playwrightもroleなどのユーザー向けlocatorを優先し、必要な場合にtest idを使う方針を案内しています。[Locators](https://playwright.dev/docs/locators)

- **fixture:** 既存のfixtureがあればそれを使います。既存パターンがない場合は、まず組み込みの `{ page }` を使い、テスト固有の準備はspec内に置きます。複数テストで同じ準備・cleanupを共有する必要が出た範囲だけ、testスコープの `test.extend` fixtureにまとめます。workerスコープは、共有しても状態が変わらない高コスト資源に限定します。fixtureは利用されたときに設定され、testスコープは各テスト後に破棄されます。[Fixtures](https://playwright.dev/docs/test-fixtures)

- **Page Object:** 既存のものがあれば再利用します。なければ、複数テストで画面操作が重複した場合に限り、対象画面に絞った小さなPage Objectを追加します。fixtureをlocator置き場にしたり、汎用fixture基盤を新設したりはしません。

この作業ツリーにはアプリ本体やE2Eコードがなく、Skillスナップショットのみでした。そのため、個別の画面locatorや既存fixtureとの統合方法はまだ確定できません。上記を実装時の既定方針として決め、実コードが見える環境で既存規約と実DOMに合わせます。
## 決定

**locatorはユーザーに見える意味を優先し、fixtureはテスト単位で必要な準備と後片付けだけを担わせます。**

このcheckoutにはアプリ本体、Playwright設定、既存specが見当たらないため、既存実装に合わせた個別指定ではなく、初期標準として決めています。既存repoの方針が確認できた場合はそれを優先する、というE2E実装Skillのルールにも沿っています。[実装Skill](/tmp/pr27-trigger-eval-snapshot-fc1478d2/.agents/skills/e2e-test-implementation/SKILL.md:14)

### Locator

1. 操作対象は `getByRole(role, { name })`、フォーム項目は `getByLabel()` を基本にします。画面上の出力確認には `getByText()` を使います。
2. 複数候補がある場合は、行やカードなどの親をlocatorで絞ってから子要素を指定します。`.nth()` は表示順自体がテスト対象のときに限ります。
3. 意味のあるlocatorで一意に特定できない場合だけ `getByTestId()` を使い、アプリ側と合意したテスト用属性として扱います。
4. CSSクラスやXPathへの依存、固定時間待ちは標準にしません。CSSが必要な場合は、そのDOM構造自体がテスト対象であることを確認します。

Playwrightも、DOM構造に結びつきやすいCSS/XPathより、roleなどユーザーが認識する属性や明示的なtest idを勧めています。[Locators](https://playwright.dev/docs/locators)・[Best Practices](https://playwright.dev/docs/best-practices)

### Fixture

- まず組み込みの `page` を使い、テストごとの分離を保ちます。
- 複数テストで再利用するPage Objectが必要なら、`test.extend()` で生成するfixtureを一つ追加します。fixture内の遷移やデータ投入は、テストから見えにくくならない範囲に限定します。
- データや状態の準備・後片付けをfixtureに置く場合はテスト単位にし、`await use(value)` の前後でライフサイクルを明示します。worker共有は、変更されない共通リソースに限ります。
- 自動fixtureや汎用fixture基盤は、全テストで必要な具体的理由がある場合だけ導入します。

```ts
import { test as base, expect } from '@playwright/test';
import { CheckoutPage } from './pages/checkout-page';

type Fixtures = {
  checkoutPage: CheckoutPage;
};

export const test = base.extend<Fixtures>({
  checkoutPage: async ({ page }, use) => {
    await use(new CheckoutPage(page));
  },
});

export { expect };
```

fixtureは必要なものだけを準備でき、`await use()` の後に後片付けを記述できます。[Playwright Fixtures](https://playwright.dev/docs/test-fixtures) 汎用Page Objectやfixtureのフレームワークは追加せず、既存構造に必要な分だけ置く方針です。[実装Skill](/tmp/pr27-trigger-eval-snapshot-fc1478d2/.agents/skills/e2e-test-implementation/SKILL.md:22)
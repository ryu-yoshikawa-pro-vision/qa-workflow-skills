## 決定

locatorとfixtureは、**対象repoで確認した既存方針を優先し、方針がない場合だけ以下の既定ルールを使う**ことにします。既存の実装方針を再利用し、汎用fixture frameworkやPage Object frameworkは追加しない契約に沿っています。[実装Skill](</tmp/pr27-agent-eval-full-d63b5588/skills/e2e-test-implementation/SKILL.md:14>) [判断基準](</tmp/pr27-agent-eval-full-d63b5588/skills/e2e-test-implementation/references/guidance.md:7>)

**Locator**

1. 操作対象は `getByRole(role, { name })`、フォーム項目は `getByLabel()`、表示内容は `getByText()` を基本にします。重複する場合は、roleなどで対象範囲を絞って一意にします。
2. user-facing locatorで対象を安定して識別できない場合は、repoで設定済みのtest id属性を使います。CSS/XPathと `.first()` / `.nth()` は、DOM構造や順序が仕様上の対象である場合に限ります。
3. 固定時間待機を置かず、Playwrightのauto-waitと再試行されるassertionを使います。

Playwrightもroleなどのuser-facing locatorを優先し、CSS/XPathや位置指定による不安定な選択を避けるよう案内しています。[Locators](https://playwright.dev/docs/locators) [Best Practices](https://playwright.dev/docs/best-practices)

**Fixture**

1. 単発テストでは標準の `page` fixtureを使います。共通の準備やページ操作が複数テストで必要なら、既存helperを使うか、近い範囲に `test.extend` のtest-scoped fixtureを作ります。Page Objectは、繰り返す操作やlocatorをまとめる価値がある場合だけ使います。
2. テストデータfixtureは、既存の確認済み準備手段でテストごとに分離し、`await use(...)` 後にteardownでcleanupします。準備にAPI等を使う場合も、検証対象のユーザー操作はUI経由で残します。
3. worker-scoped fixtureは、共有しても状態が混ざらない高コスト資源に限定します。ページや変更される業務データはテスト間で共有しません。

Playwrightのfixtureは必要なものだけ遅延準備でき、test scopeでは各テスト後にteardownできます。Page Objectも任意の構成手法です。[Fixtures](https://playwright.dev/docs/test-fixtures) [Page Object Models](https://playwright.dev/docs/pom)

PR #27の担当文書は、E2E選定を技術非依存に保ち、既存Playwright Skillの実装・実行責務を複製しないとしています。[担当文書](</tmp/pr27-agent-eval-full-d63b5588/docs/implementation/pr22/E_formal-design-e2e-selection.md:72>) したがって、この決定は選定Skillではなく、既存のE2E実装Skillに属する方針です。[選定Skill](</tmp/pr27-agent-eval-full-d63b5588/skills/e2e-test-selection/SKILL.md:10>)

このcheckoutにはPlaywright設定・spec・製品コードがなく、`.git`も確認できませんでした。そのため、対象画面の実locatorや具体的fixtureは未確定です。実装時は `e2e-test-inspection` で対象と既存構成を確認してから適用します。ドキュメントと実装コードの食い違いは確認していません。コード変更・テスト実行はありません。
## 決定

locatorは、既存repoに方針があればそれに合わせます。このworkspaceにはPlaywrightの設定・specがないため、共通方針として次を採用します。

- 操作要素は`getByRole`、入力欄は`getByLabel`、表示内容は`getByText`を優先します。例：`getByRole('button', { name: '保存', exact: true })`
- 同じ名前の要素が複数ある場合は、意味のある親要素からlocatorを絞ります。`nth()`は順序自体がテスト対象の場合に限ります。
- `getByTestId`はユーザー向けの名前で安定して特定できない場合に使い、明示的なテスト用契約として追加します。CSS/XPathによるDOM構造依存の指定は原則避けます。固定時間待機も標準手段にしません。Playwrightもユーザー視点のlocatorを推奨し、CSS/XPathや位置指定には注意を促しています。[Locators](https://playwright.dev/docs/locators) · [Best Practices](https://playwright.dev/docs/best-practices)

fixtureは、Playwright Testの標準fixtureを基本にします。

- `page`、`context`など標準fixtureを使い、単一テストの準備はそのテスト内、単一ファイルだけで共有する簡単な準備はローカルhelperやhookに置きます。
- 複数テストで再利用する状態準備やcleanupが必要になった時点で、対象テスト群のmoduleに`test.extend`でfixtureを定義します。可変データはtest scopeを既定にし、各テストで独立させてfixtureのteardownで後片付けします。
- worker scopeは、worker単位で共有しても並列実行を妨げない基盤に限ります。すべてのテストで必要な処理でない限りautomatic fixtureにしません。汎用fixture frameworkや一律必須のPage Objectは追加しません。これはrepoの[E2E実装契約](</tmp/pr27-agent-eval-full-d63b5588/skills/e2e-test-implementation/SKILL.md>)と、Playwrightの[fixtureのsetup・teardown・scope](https://playwright.dev/docs/test-fixtures)に沿った判断です。

## 現時点で決められない範囲

対象画面、URL、TC、実アプリが指定されておらず、このrepoにもPlaywrightの設定やspecがありません。そのため、実際のDOMに対するlocator、データ準備API、fixtureの置き場所までは確定できません。上記を共通の実装基準として決定し、具体的な対象が分かった段階で既存構成に合わせます。

ファイル変更・テスト実行はしていません。Git metadataがないためbranch・HEADも確認できませんでした。ドキュメントとPlaywright実装コードの不整合は確認していません（比較対象となる実装コードがありません）。